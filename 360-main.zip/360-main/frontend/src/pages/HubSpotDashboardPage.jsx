import { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { hubspotApi } from '@/lib/api';
import { cn, formatDateTime } from '@/lib/utils';
import { 
  Settings, 
  RefreshCw, 
  Loader2,
  TrendingUp,
  Phone,
  Mail,
  ListTodo
} from 'lucide-react';
import { toast } from 'sonner';

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount || 0);
};

export default function HubSpotDashboardPage() {
  const [configured, setConfigured] = useState(false);
  const [loading, setLoading] = useState(true);
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [saving, setSaving] = useState(false);
  const [pipelineSummary, setPipelineSummary] = useState(null);
  const [activities, setActivities] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const fetchDashboardData = useCallback(async () => {
    setRefreshing(true);
    try {
      const pipelineRes = await hubspotApi.getPipelineSummary();
      const activitiesRes = await hubspotApi.getActivities(20);
      setPipelineSummary(pipelineRes.data);
      setActivities(activitiesRes.data.activities || []);
    } catch (error) {
      if (error.response?.status === 400) {
        toast.error('HubSpot API key may be invalid');
      } else {
        toast.error('Failed to fetch HubSpot data');
      }
    } finally {
      setRefreshing(false);
    }
  }, []);

  const checkStatus = useCallback(async () => {
    try {
      const res = await hubspotApi.getStatus();
      setConfigured(res.data.configured);
      if (res.data.configured) {
        await fetchDashboardData();
      }
    } catch (error) {
      console.error('Failed to check HubSpot status');
    } finally {
      setLoading(false);
    }
  }, [fetchDashboardData]);

  useEffect(() => {
    checkStatus();
  }, [checkStatus]);

  const handleSaveApiKey = async () => {
    if (!apiKey.trim()) {
      toast.error('Please enter an API key');
      return;
    }
    setSaving(true);
    try {
      await hubspotApi.configure(apiKey);
      toast.success('HubSpot API key saved successfully');
      setConfigured(true);
      setConfigDialogOpen(false);
      setApiKey('');
      await fetchDashboardData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save API key');
    } finally {
      setSaving(false);
    }
  };

  const renderActivityIcon = (type) => {
    if (type === 'call') return <Phone className="w-4 h-4" />;
    if (type === 'email') return <Mail className="w-4 h-4" />;
    return <ListTodo className="w-4 h-4" />;
  };

  const getActivityColor = (type) => {
    if (type === 'call') return 'bg-blue-100 text-blue-700';
    if (type === 'email') return 'bg-purple-100 text-purple-700';
    return 'bg-amber-100 text-amber-700';
  };

  if (loading) {
    return (
      <MainLayout title="HubSpot Dashboard">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
        </div>
      </MainLayout>
    );
  }

  const pipelines = pipelineSummary?.pipelines || [];

  return (
    <MainLayout 
      title="HubSpot Dashboard"
      actions={
        <div className="flex items-center gap-3">
          {configured && (
            <Button 
              variant="outline" 
              onClick={fetchDashboardData}
              disabled={refreshing}
              data-testid="refresh-hubspot-btn"
            >
              <RefreshCw className={cn("w-4 h-4 mr-2", refreshing && "animate-spin")} />
              Refresh
            </Button>
          )}
          <Button 
            variant="outline" 
            onClick={() => setConfigDialogOpen(true)}
            data-testid="hubspot-settings-btn"
          >
            <Settings className="w-4 h-4 mr-2" />
            {configured ? 'Update API Key' : 'Configure'}
          </Button>
        </div>
      }
    >
      <div className="space-y-6" data-testid="hubspot-dashboard-page">
        {!configured && (
          <Card className="border border-slate-200 shadow-sm">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <Settings className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">HubSpot Not Configured</h3>
              <p className="text-slate-500 text-center mb-4 max-w-md">
                Connect your HubSpot account to view deal pipeline summaries and recent activities.
              </p>
              <Button onClick={() => setConfigDialogOpen(true)} data-testid="configure-hubspot-btn">
                Configure HubSpot
              </Button>
            </CardContent>
          </Card>
        )}

        {configured && (
          <>
            <Card className="border border-slate-200 shadow-sm" data-testid="pipeline-summary-card">
              <CardHeader>
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Deal Pipeline Summary
                </CardTitle>
                <CardDescription>
                  Overview of your HubSpot deal pipelines
                </CardDescription>
              </CardHeader>
              <CardContent>
                {refreshing && pipelines.length === 0 ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                  </div>
                ) : pipelines.length > 0 ? (
                  <div className="space-y-6">
                    {pipelines.map((pipeline, pIdx) => (
                      <div key={`pipeline-${pIdx}`} className="border border-slate-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="font-semibold text-slate-900">{pipeline.label}</h4>
                          <div className="flex items-center gap-4">
                            <Badge variant="secondary">{pipeline.total_deals} deals</Badge>
                            <span className="font-semibold text-emerald-600">
                              {formatCurrency(pipeline.total_value)}
                            </span>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                          {(pipeline.stages || []).map((stage, sIdx) => (
                            <div key={`stage-${pIdx}-${sIdx}`} className="bg-slate-50 rounded-lg p-3 border border-slate-100">
                              <p className="text-xs text-slate-500 truncate mb-1">{stage.label}</p>
                              <p className="text-lg font-bold text-slate-900">{stage.deal_count}</p>
                              <p className="text-xs text-emerald-600 font-medium">
                                {formatCurrency(stage.total_amount)}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-center py-8">No pipeline data available</p>
                )}
              </CardContent>
            </Card>

            <Card className="border border-slate-200 shadow-sm" data-testid="recent-activities-card">
              <CardHeader>
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <ListTodo className="w-5 h-5" />
                  Recent Activities
                </CardTitle>
                <CardDescription>
                  Latest tasks, calls, and emails from HubSpot
                </CardDescription>
              </CardHeader>
              <CardContent>
                {refreshing && activities.length === 0 ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                  </div>
                ) : activities.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {activities.map((activity, idx) => (
                      <div 
                        key={`activity-${idx}`}
                        className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100"
                      >
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                          getActivityColor(activity.type)
                        )}>
                          {renderActivityIcon(activity.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className={cn("text-xs capitalize", getActivityColor(activity.type))}>
                              {activity.type}
                            </Badge>
                            {activity.status && (
                              <Badge variant="outline" className="text-xs">{activity.status}</Badge>
                            )}
                          </div>
                          <p className="font-medium text-sm text-slate-900 truncate">
                            {activity.subject || 'No subject'}
                          </p>
                          <p className="text-xs text-slate-400 mt-1">
                            {formatDateTime(activity.updated_at)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 text-center py-8">No recent activities</p>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Configure HubSpot</DialogTitle>
            <DialogDescription>
              Enter your HubSpot Private App access token to connect
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="api_key">Private App Access Token</Label>
              <Input
                id="api_key"
                type="password"
                placeholder="pat-na1-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                data-testid="hubspot-api-key-input"
              />
              <p className="text-xs text-slate-500">
                Find this in HubSpot Settings → Integrations → Private Apps
              </p>
            </div>
            <div className="bg-slate-50 rounded-lg p-3 text-sm">
              <p className="font-medium mb-2">Required Scopes:</p>
              <p className="text-xs text-slate-600">
                crm.objects.contacts.read, crm.objects.companies.read, crm.objects.deals.read, crm.schemas.deals.read, crm.objects.tasks.read
              </p>
            </div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setConfigDialogOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handleSaveApiKey}
                disabled={saving}
                className="flex-1"
                data-testid="save-hubspot-key-btn"
              >
                {saving ? 'Saving...' : 'Save & Connect'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
