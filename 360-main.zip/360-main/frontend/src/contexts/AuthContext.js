import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL;

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);
  const [mfaPending, setMfaPending] = useState(null);

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('token');
      if (storedToken) {
        try {
          const response = await axios.get(`${API_URL}/api/auth/me`, {
            headers: { Authorization: `Bearer ${storedToken}` }
          });
          setUser(response.data);
          setToken(storedToken);
        } catch (error) {
          localStorage.removeItem('token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);

  const login = async (email, password) => {
    const response = await axios.post(`${API_URL}/api/auth/login`, { email, password });
    const data = response.data;
    
    // Check if MFA is required
    if (data.requires_mfa) {
      setMfaPending({
        mfa_token: data.mfa_token,
        mfa_method: data.mfa_method,
        message: data.message
      });
      return { requires_mfa: true, mfa_method: data.mfa_method, message: data.message };
    }
    
    // No MFA - direct login
    const { access_token, user: userData } = data;
    localStorage.setItem('token', access_token);
    setToken(access_token);
    setUser(userData);
    setMfaPending(null);
    return { requires_mfa: false, user: userData };
  };

  const verifyMfa = async (code) => {
    if (!mfaPending) {
      throw new Error('No MFA session pending');
    }
    
    const response = await axios.post(`${API_URL}/api/auth/verify-mfa`, {
      mfa_token: mfaPending.mfa_token,
      code: code
    });
    
    const { access_token, user: userData } = response.data;
    localStorage.setItem('token', access_token);
    setToken(access_token);
    setUser(userData);
    setMfaPending(null);
    return userData;
  };

  const resendMfaCode = async () => {
    if (!mfaPending) {
      throw new Error('No MFA session pending');
    }
    
    await axios.post(`${API_URL}/api/mfa/resend-code`, null, {
      params: { mfa_token: mfaPending.mfa_token }
    });
  };

  const cancelMfa = () => {
    setMfaPending(null);
  };

  const register = async (name, email, password) => {
    const response = await axios.post(`${API_URL}/api/auth/register`, { name, email, password });
    const { access_token, user: userData } = response.data;
    localStorage.setItem('token', access_token);
    setToken(access_token);
    setUser(userData);
    return userData;
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    setMfaPending(null);
  };

  const getAuthHeader = () => {
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  const refreshUser = async () => {
    if (token) {
      try {
        const response = await axios.get(`${API_URL}/api/auth/me`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setUser(response.data);
      } catch (error) {
        console.error('Failed to refresh user');
      }
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      loading,
      isAuthenticated: !!token,
      mfaPending,
      login,
      verifyMfa,
      resendMfaCode,
      cancelMfa,
      register,
      logout,
      getAuthHeader,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};
