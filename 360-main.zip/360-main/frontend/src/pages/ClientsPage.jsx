import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { clientsApi, projectsApi } from '@/lib/api';
import { cn, getTierClass, CLIENT_TIERS } from '@/lib/utils';
import { Plus, Search, MoreVertical, Building2, User, Mail, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ClientsPage() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [projectCounts, setProjectCounts] = useState({});

  // Form state
  const [formData, setFormData] = useState({
    company_name: '',
    poc_name: '',
    poc_email: '',
    notes: '',
    tier: 'Tier 2'
  });

  useEffect(() => {
    fetchClients();
  }, [search, tierFilter]);

  const fetchClients = async () => {
    try {
      const params = {};
      if (search) params.search = search;
      if (tierFilter && tierFilter !== 'all') params.tier = tierFilter;
      
      const [clientsRes, projectsRes] = await Promise.all([
        clientsApi.getAll(params),
        projectsApi.getAll()
      ]);
      
      setClients(clientsRes.data);
      
      // Count projects per client
      const counts = {};
      projectsRes.data.forEach(p => {
        counts[p.client_id] = (counts[p.client_id] || 0) + 1;
      });
      setProjectCounts(counts);
    } catch (error) {
      toast.error('Failed to load clients');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingClient) {
        await clientsApi.update(editingClient.id, formData);
        toast.success('Client updated successfully');
      } else {
        await clientsApi.create(formData);
        toast.success('Client created successfully');
      }
      setIsDialogOpen(false);
      resetForm();
      fetchClients();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save client');
    }
  };

  const handleEdit = (client) => {
    setEditingClient(client);
    setFormData({
      company_name: client.company_name,
      poc_name: client.poc_name,
      poc_email: client.poc_email,
      notes: client.notes || '',
      tier: client.tier
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (clientId) => {
    if (!window.confirm('Are you sure you want to delete this client? This will also delete all associated projects.')) {
      return;
    }
    try {
      await clientsApi.delete(clientId);
      toast.success('Client deleted successfully');
      fetchClients();
    } catch (error) {
      toast.error('Failed to delete client');
    }
  };

  const resetForm = () => {
    setEditingClient(null);
    setFormData({
      company_name: '',
      poc_name: '',
      poc_email: '',
      notes: '',
      tier: 'Tier 2'
    });
  };

  return (
    <MainLayout 
      title="Clients"
      actions={
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button data-testid="add-client-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Client
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{editingClient ? 'Edit Client' : 'Add New Client'}</DialogTitle>
              <DialogDescription>
                {editingClient ? 'Update client information' : 'Add a new client to your system'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="company_name">Company Name</Label>
                <Input
                  id="company_name"
                  value={formData.company_name}
                  onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                  placeholder="Acme Corporation"
                  required
                  data-testid="client-company-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="poc_name">POC Name</Label>
                <Input
                  id="poc_name"
                  value={formData.poc_name}
                  onChange={(e) => setFormData({ ...formData, poc_name: e.target.value })}
                  placeholder="John Smith"
                  required
                  data-testid="client-poc-name-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="poc_email">POC Email</Label>
                <Input
                  id="poc_email"
                  type="email"
                  value={formData.poc_email}
                  onChange={(e) => setFormData({ ...formData, poc_email: e.target.value })}
                  placeholder="john@acme.com"
                  required
                  data-testid="client-poc-email-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tier">Client Tier</Label>
                <Select 
                  value={formData.tier} 
                  onValueChange={(value) => setFormData({ ...formData, tier: value })}
                >
                  <SelectTrigger data-testid="client-tier-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CLIENT_TIERS.map((tier) => (
                      <SelectItem key={tier} value={tier}>{tier}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes about this client..."
                  rows={3}
                  data-testid="client-notes-input"
                />
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" data-testid="client-submit-btn">
                  {editingClient ? 'Update Client' : 'Add Client'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="space-y-6" data-testid="clients-page">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search clients..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
              data-testid="client-search-input"
            />
          </div>
          <Select value={tierFilter} onValueChange={setTierFilter}>
            <SelectTrigger className="w-full sm:w-40" data-testid="tier-filter-select">
              <SelectValue placeholder="Filter by tier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tiers</SelectItem>
              {CLIENT_TIERS.map((tier) => (
                <SelectItem key={tier} value={tier}>{tier}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Clients Grid */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
          </div>
        ) : clients.length === 0 ? (
          <Card className="border border-slate-200">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Building2 className="w-12 h-12 text-slate-300 mb-4" />
              <p className="text-slate-500 mb-4">No clients found</p>
              <Button onClick={() => setIsDialogOpen(true)} data-testid="empty-add-client-btn">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Client
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {clients.map((client, index) => (
              <Card 
                key={client.id}
                className={cn(
                  "border border-slate-200 shadow-sm hover:shadow-md transition-shadow animate-fade-in",
                  `stagger-${(index % 5) + 1}`
                )}
                data-testid={`client-card-${client.id}`}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <Link to={`/clients/${client.id}`} className="flex-1 min-w-0">
                      <h3 className="font-semibold text-slate-900 truncate hover:text-emerald-600 transition-colors">
                        {client.company_name}
                      </h3>
                    </Link>
                    <div className="flex items-center gap-2 ml-2">
                      <Badge className={cn("text-xs", getTierClass(client.tier))}>
                        {client.tier}
                      </Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid={`client-menu-${client.id}`}>
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(client)} data-testid={`edit-client-${client.id}`}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDelete(client.id)}
                            className="text-rose-600"
                            data-testid={`delete-client-${client.id}`}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-slate-600">
                      <User className="w-4 h-4 text-slate-400" />
                      <span className="truncate">{client.poc_name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-600">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <span className="truncate">{client.poc_email}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                      {projectCounts[client.id] || 0} project{(projectCounts[client.id] || 0) !== 1 ? 's' : ''}
                    </span>
                    <Link to={`/clients/${client.id}`}>
                      <Button variant="ghost" size="sm" className="text-xs" data-testid={`view-client-${client.id}`}>
                        View Details
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
