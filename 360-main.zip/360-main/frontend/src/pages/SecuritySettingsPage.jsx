import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { mfaApi } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { Shield, Smartphone, Mail, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function SecuritySettingsPage() {
  const { user, refreshUser } = useAuth();
  const [mfaStatus, setMfaStatus] = useState({ mfa_enabled: false, mfa_method: null });
  const [loading, setLoading] = useState(true);
  const [setupDialogOpen, setSetupDialogOpen] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [setupData, setSetupData] = useState(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [setupLoading, setSetupLoading] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  useEffect(() => {
    fetchMfaStatus();
  }, []);

  const fetchMfaStatus = async () => {
    try {
      const res = await mfaApi.getStatus();
      setMfaStatus(res.data);
    } catch (error) {
      toast.error('Failed to load MFA status');
    } finally {
      setLoading(false);
    }
  };

  const handleSetupStart = async (method) => {
    setSelectedMethod(method);
    setSetupLoading(true);
    try {
      const res = await mfaApi.setup(method);
      setSetupData(res.data);
      setSetupDialogOpen(true);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to start MFA setup');
    } finally {
      setSetupLoading(false);
    }
  };

  const handleEnableMfa = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      toast.error('Please enter a 6-digit code');
      return;
    }

    setSetupLoading(true);
    try {
      const res = await mfaApi.enable(selectedMethod, verificationCode);
      toast.success(res.data.message);
      setSetupDialogOpen(false);
      setVerificationCode('');
      setSetupData(null);
      fetchMfaStatus();
      refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to enable MFA');
    } finally {
      setSetupLoading(false);
    }
  };

  const handleDisableMfa = async () => {
    if (!window.confirm('Are you sure you want to disable MFA? This will make your account less secure.')) {
      return;
    }

    setDisableLoading(true);
    try {
      await mfaApi.disable();
      toast.success('MFA disabled successfully');
      fetchMfaStatus();
      refreshUser();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to disable MFA');
    } finally {
      setDisableLoading(false);
    }
  };

  const closeSetupDialog = () => {
    setSetupDialogOpen(false);
    setVerificationCode('');
    setSetupData(null);
    setSelectedMethod(null);
  };

  if (loading) {
    return (
      <MainLayout title="Security Settings">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Security Settings">
      <div className="max-w-2xl space-y-6" data-testid="security-settings-page">
        {/* MFA Status Card */}
        <Card className="border border-slate-200 shadow-sm" data-testid="mfa-status-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <CardTitle className="text-base font-semibold">Two-Factor Authentication</CardTitle>
                  <CardDescription>Add an extra layer of security to your account</CardDescription>
                </div>
              </div>
              {mfaStatus.mfa_enabled ? (
                <Badge className="bg-emerald-100 text-emerald-700 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" />
                  Enabled
                </Badge>
              ) : (
                <Badge variant="secondary" className="flex items-center gap-1">
                  <XCircle className="w-3 h-3" />
                  Disabled
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {mfaStatus.mfa_enabled ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                  {mfaStatus.mfa_method === 'totp' ? (
                    <Smartphone className="w-5 h-5 text-slate-600" />
                  ) : (
                    <Mail className="w-5 h-5 text-slate-600" />
                  )}
                  <div>
                    <p className="font-medium text-sm">
                      {mfaStatus.mfa_method === 'totp' ? 'Authenticator App' : 'Email Verification'}
                    </p>
                    <p className="text-xs text-slate-500">
                      {mfaStatus.mfa_method === 'totp' 
                        ? 'Using time-based one-time passwords'
                        : 'Verification codes sent to your email'
                      }
                    </p>
                  </div>
                </div>
                <Button 
                  variant="destructive" 
                  onClick={handleDisableMfa}
                  disabled={disableLoading}
                  data-testid="disable-mfa-btn"
                >
                  {disableLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Disabling...
                    </>
                  ) : (
                    'Disable MFA'
                  )}
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Choose how you want to receive your verification codes:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    onClick={() => handleSetupStart('totp')}
                    disabled={setupLoading}
                    className="p-4 border border-slate-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors text-left"
                    data-testid="setup-totp-btn"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <Smartphone className="w-5 h-5 text-slate-600" />
                      <span className="font-medium">Authenticator App</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Use Google Authenticator, Authy, or similar apps
                    </p>
                  </button>
                  <button
                    onClick={() => handleSetupStart('email')}
                    disabled={setupLoading}
                    className="p-4 border border-slate-200 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors text-left"
                    data-testid="setup-email-btn"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <Mail className="w-5 h-5 text-slate-600" />
                      <span className="font-medium">Email</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Receive verification codes via email
                    </p>
                  </button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Account Info Card */}
        <Card className="border border-slate-200 shadow-sm" data-testid="account-info-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold">Account Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-xs text-slate-500 uppercase tracking-wide">Name</Label>
              <p className="font-medium">{user?.name}</p>
            </div>
            <div>
              <Label className="text-xs text-slate-500 uppercase tracking-wide">Email</Label>
              <p className="font-medium">{user?.email}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* MFA Setup Dialog */}
      <Dialog open={setupDialogOpen} onOpenChange={closeSetupDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedMethod === 'totp' ? 'Setup Authenticator App' : 'Setup Email Verification'}
            </DialogTitle>
            <DialogDescription>
              {setupData?.message}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            {selectedMethod === 'totp' && setupData?.qr_code && (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <img 
                    src={`data:image/png;base64,${setupData.qr_code}`} 
                    alt="QR Code"
                    className="border rounded-lg"
                    data-testid="totp-qr-code"
                  />
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-500 mb-1">Or enter this code manually:</p>
                  <code className="bg-slate-100 px-3 py-1 rounded text-sm font-mono" data-testid="totp-secret">
                    {setupData.secret}
                  </code>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="verification_code">
                {selectedMethod === 'totp' 
                  ? 'Enter code from your authenticator app'
                  : 'Enter code sent to your email'
                }
              </Label>
              <Input
                id="verification_code"
                type="text"
                inputMode="numeric"
                maxLength={6}
                placeholder="000000"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                className="text-center text-xl tracking-widest"
                data-testid="mfa-setup-code-input"
              />
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={closeSetupDialog} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handleEnableMfa}
                disabled={setupLoading || verificationCode.length !== 6}
                className="flex-1"
                data-testid="confirm-mfa-setup-btn"
              >
                {setupLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enabling...
                  </>
                ) : (
                  'Enable MFA'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
