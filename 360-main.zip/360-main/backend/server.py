from fastapi import FastAPI, APIRouter, HTTPException, Depends, BackgroundTasks, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import Response, StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import bcrypt
from bson import ObjectId
import pyotp
import qrcode
import io
import base64
import random
import string
import httpx
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Settings
SECRET_KEY = os.environ['SECRET_KEY']
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24
MFA_TOKEN_EXPIRE_MINUTES = 10

# SMTP Settings
SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.office365.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
SMTP_USER = os.environ.get('SMTP_USER', '')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '')
SMTP_FROM_EMAIL = os.environ.get('SMTP_FROM_EMAIL', '')
SMTP_FROM_NAME = os.environ.get('SMTP_FROM_NAME', 'Project Management System')

# HubSpot Settings
HUBSPOT_API_KEY = os.environ.get('HUBSPOT_API_KEY', '')
HUBSPOT_BASE_URL = "https://api.hubapi.com"

# Create the main app
app = FastAPI(title="Client Project Management System")

# Create routers
api_router = APIRouter(prefix="/api")
auth_router = APIRouter(prefix="/api/auth")
mfa_router = APIRouter(prefix="/api/mfa")
clients_router = APIRouter(prefix="/api/clients")
projects_router = APIRouter(prefix="/api/projects")
email_router = APIRouter(prefix="/api/email")
dashboard_router = APIRouter(prefix="/api/dashboard")
bulk_router = APIRouter(prefix="/api/bulk")
hubspot_router = APIRouter(prefix="/api/hubspot")

security = HTTPBearer()
optional_security = HTTPBearer(auto_error=False)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Status Options
PROJECT_STATUSES = [
    "Planning Calls Scheduled",
    "Director Planning Review",
    "Planning Calls Completed",
    "Kickoff Calls Scheduled",
    "COU Scheduled",
    "1-25% Evidence Received",
    "26-50% Evidence Received",
    "51-75% Evidence Received",
    "76-99% Evidence Received",
    "100% Evidence Received",
    "Detail QA Review",
    "Manager Conclusion Review",
    "Director Review",
    "With Final QC Review",
    "Draft Report and Concluding Steps Provided to Client",
    "Report(s) Issued",
    "Closing Call Needed",
    "Completed",
    "Issued"
]

PRIORITY_LEVELS = ["Low", "Medium", "High", "Critical"]
CLIENT_TIERS = ["Tier 1", "Tier 2", "Tier 3"]  # Reduced from 4 to 3

# ==================== MODELS ====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    email: str
    name: str
    created_at: str
    mfa_enabled: bool = False
    mfa_method: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse
    requires_mfa: bool = False

class MFALoginResponse(BaseModel):
    requires_mfa: bool = True
    mfa_method: str
    mfa_token: str
    message: str

class MFAVerifyRequest(BaseModel):
    mfa_token: str
    code: str

class MFASetupRequest(BaseModel):
    method: str  # "totp" or "email"

class MFASetupResponse(BaseModel):
    method: str
    secret: Optional[str] = None
    qr_code: Optional[str] = None
    message: str

class MFAEnableRequest(BaseModel):
    method: str
    code: str

class ClientCreate(BaseModel):
    company_name: str
    poc_name: str
    poc_email: EmailStr
    notes: Optional[str] = ""
    tier: str = "Tier 2"

class ClientUpdate(BaseModel):
    company_name: Optional[str] = None
    poc_name: Optional[str] = None
    poc_email: Optional[EmailStr] = None
    notes: Optional[str] = None
    tier: Optional[str] = None

class ClientResponse(BaseModel):
    id: str
    company_name: str
    poc_name: str
    poc_email: str
    notes: str
    tier: str
    created_at: str
    updated_at: str

class ProjectCreate(BaseModel):
    client_id: str
    name: str
    description: Optional[str] = ""
    status: str = "Planning Calls Scheduled"
    priority: str = "Medium"
    due_date: str
    notes: Optional[str] = ""

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    due_date: Optional[str] = None
    notes: Optional[str] = None

class ProjectResponse(BaseModel):
    id: str
    client_id: str
    client_name: Optional[str] = None
    name: str
    description: str
    status: str
    priority: str
    due_date: str
    notes: str
    created_at: str
    updated_at: str

class EmailSettingsCreate(BaseModel):
    enabled: bool = True
    frequency: str = "weekly"
    day_of_week: str = "Monday"
    time_of_day: str = "09:00"
    recipients: List[EmailStr] = []

class EmailSettingsResponse(BaseModel):
    id: str
    user_id: str
    enabled: bool
    frequency: str
    day_of_week: str
    time_of_day: str
    recipients: List[str]
    last_sent: Optional[str] = None
    updated_at: str

class DashboardStats(BaseModel):
    total_clients: int
    total_projects: int
    projects_by_status: dict
    projects_by_priority: dict
    overdue_projects: int
    due_this_week: int
    clients_by_tier: dict

# ==================== HELPERS ====================

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str, email: str, token_type: str = "access") -> str:
    if token_type == "mfa":
        expire = datetime.now(timezone.utc) + timedelta(minutes=MFA_TOKEN_EXPIRE_MINUTES)
    else:
        expire = datetime.now(timezone.utc) + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS)
    payload = {
        "sub": user_id,
        "email": email,
        "type": token_type,
        "exp": expire
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def generate_otp_code() -> str:
    return ''.join(random.choices(string.digits, k=6))

def generate_totp_secret() -> str:
    return pyotp.random_base32()

def verify_totp(secret: str, code: str) -> bool:
    totp = pyotp.TOTP(secret)
    return totp.verify(code, valid_window=1)

def generate_qr_code(secret: str, email: str) -> str:
    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=email, issuer_name="ClientHub")
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    return base64.b64encode(buffer.getvalue()).decode()

async def send_otp_email(email: str, code: str):
    if not SMTP_USER or not SMTP_PASSWORD:
        logger.warning("SMTP not configured, OTP code would be: " + code)
        return
    
    try:
        html = f"""
        <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h2>Your Verification Code</h2>
            <p>Use the following code to complete your login:</p>
            <div style="background: #f0f0f0; padding: 20px; text-align: center; font-size: 32px; letter-spacing: 8px; font-weight: bold;">
                {code}
            </div>
            <p style="color: #666; margin-top: 20px;">This code expires in 10 minutes.</p>
            <p style="color: #666;">If you didn't request this code, please ignore this email.</p>
        </body>
        </html>
        """
        
        msg = MIMEMultipart("alternative")
        msg["From"] = f"{SMTP_FROM_NAME} <{SMTP_FROM_EMAIL}>"
        msg["To"] = email
        msg["Subject"] = "Your Login Verification Code"
        msg.attach(MIMEText(html, "html"))
        
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        
        logger.info(f"OTP email sent to {email}")
    except Exception as e:
        logger.error(f"Failed to send OTP email: {str(e)}")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        token_type = payload.get("type", "access")
        
        if not user_id or token_type != "access":
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ==================== AUTH ROUTES ====================

@auth_router.post("/register")
async def register(user_data: UserCreate):
    existing = await db.users.find_one({"email": user_data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    
    user_doc = {
        "id": user_id,
        "email": user_data.email,
        "password_hash": hash_password(user_data.password),
        "name": user_data.name,
        "mfa_enabled": False,
        "mfa_method": None,
        "totp_secret": None,
        "created_at": now,
        "updated_at": now
    }
    
    await db.users.insert_one(user_doc)
    
    token = create_token(user_id, user_data.email)
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(
            id=user_id,
            email=user_data.email,
            name=user_data.name,
            created_at=now,
            mfa_enabled=False,
            mfa_method=None
        ),
        requires_mfa=False
    )

@auth_router.post("/login")
async def login(credentials: UserLogin, background_tasks: BackgroundTasks):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    if not verify_password(credentials.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Check if MFA is enabled
    if user.get("mfa_enabled") and user.get("mfa_method"):
        mfa_token = create_token(user["id"], user["email"], token_type="mfa")
        
        if user["mfa_method"] == "email":
            # Generate and send OTP
            otp_code = generate_otp_code()
            await db.mfa_codes.update_one(
                {"user_id": user["id"]},
                {"$set": {
                    "code": otp_code,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
                }},
                upsert=True
            )
            background_tasks.add_task(send_otp_email, user["email"], otp_code)
            
            return MFALoginResponse(
                requires_mfa=True,
                mfa_method="email",
                mfa_token=mfa_token,
                message="Verification code sent to your email"
            )
        else:  # TOTP
            return MFALoginResponse(
                requires_mfa=True,
                mfa_method="totp",
                mfa_token=mfa_token,
                message="Enter the code from your authenticator app"
            )
    
    # No MFA - return access token
    token = create_token(user["id"], user["email"])
    
    return TokenResponse(
        access_token=token,
        user=UserResponse(
            id=user["id"],
            email=user["email"],
            name=user["name"],
            created_at=user["created_at"],
            mfa_enabled=user.get("mfa_enabled", False),
            mfa_method=user.get("mfa_method")
        ),
        requires_mfa=False
    )

@auth_router.post("/verify-mfa", response_model=TokenResponse)
async def verify_mfa(data: MFAVerifyRequest):
    try:
        payload = jwt.decode(data.mfa_token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        token_type = payload.get("type")
        
        if not user_id or token_type != "mfa":
            raise HTTPException(status_code=401, detail="Invalid MFA token")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        
        # Verify the code based on MFA method
        if user["mfa_method"] == "email":
            mfa_code = await db.mfa_codes.find_one({"user_id": user_id})
            if not mfa_code or mfa_code["code"] != data.code:
                raise HTTPException(status_code=401, detail="Invalid verification code")
            
            # Check expiry
            if datetime.fromisoformat(mfa_code["expires_at"]) < datetime.now(timezone.utc):
                raise HTTPException(status_code=401, detail="Verification code expired")
            
            # Delete used code
            await db.mfa_codes.delete_one({"user_id": user_id})
            
        elif user["mfa_method"] == "totp":
            if not user.get("totp_secret"):
                raise HTTPException(status_code=400, detail="TOTP not configured")
            
            if not verify_totp(user["totp_secret"], data.code):
                raise HTTPException(status_code=401, detail="Invalid verification code")
        
        # Generate access token
        token = create_token(user["id"], user["email"])
        
        return TokenResponse(
            access_token=token,
            user=UserResponse(
                id=user["id"],
                email=user["email"],
                name=user["name"],
                created_at=user["created_at"],
                mfa_enabled=user.get("mfa_enabled", False),
                mfa_method=user.get("mfa_method")
            ),
            requires_mfa=False
        )
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="MFA session expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid MFA token")

@auth_router.get("/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    return UserResponse(
        id=current_user["id"],
        email=current_user["email"],
        name=current_user["name"],
        created_at=current_user["created_at"],
        mfa_enabled=current_user.get("mfa_enabled", False),
        mfa_method=current_user.get("mfa_method")
    )

# ==================== MFA ROUTES ====================

@mfa_router.post("/setup", response_model=MFASetupResponse)
async def setup_mfa(data: MFASetupRequest, current_user: dict = Depends(get_current_user)):
    if data.method not in ["totp", "email"]:
        raise HTTPException(status_code=400, detail="Invalid MFA method. Use 'totp' or 'email'")
    
    if data.method == "totp":
        # Generate TOTP secret
        secret = generate_totp_secret()
        qr_code = generate_qr_code(secret, current_user["email"])
        
        # Store pending secret
        await db.users.update_one(
            {"id": current_user["id"]},
            {"$set": {"pending_totp_secret": secret}}
        )
        
        return MFASetupResponse(
            method="totp",
            secret=secret,
            qr_code=qr_code,
            message="Scan the QR code with your authenticator app, then verify with a code"
        )
    else:
        return MFASetupResponse(
            method="email",
            message="Email MFA will send a verification code to your email during login"
        )

@mfa_router.post("/enable")
async def enable_mfa(
    data: MFAEnableRequest,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    if data.method not in ["totp", "email"]:
        raise HTTPException(status_code=400, detail="Invalid MFA method")
    
    if data.method == "totp":
        # Verify the code against pending secret
        user = await db.users.find_one({"id": current_user["id"]}, {"_id": 0})
        pending_secret = user.get("pending_totp_secret")
        
        if not pending_secret:
            raise HTTPException(status_code=400, detail="Please setup TOTP first")
        
        if not verify_totp(pending_secret, data.code):
            raise HTTPException(status_code=401, detail="Invalid verification code")
        
        # Enable TOTP
        await db.users.update_one(
            {"id": current_user["id"]},
            {"$set": {
                "mfa_enabled": True,
                "mfa_method": "totp",
                "totp_secret": pending_secret,
                "pending_totp_secret": None
            }}
        )
        
        return {"message": "TOTP MFA enabled successfully"}
    
    else:  # email
        # Send test OTP to verify email works
        otp_code = generate_otp_code()
        await db.mfa_codes.update_one(
            {"user_id": current_user["id"], "type": "setup"},
            {"$set": {
                "code": otp_code,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
            }},
            upsert=True
        )
        
        # Check if code matches (for enabling)
        mfa_code = await db.mfa_codes.find_one({"user_id": current_user["id"], "type": "setup"})
        if mfa_code and mfa_code["code"] == data.code:
            await db.users.update_one(
                {"id": current_user["id"]},
                {"$set": {
                    "mfa_enabled": True,
                    "mfa_method": "email"
                }}
            )
            await db.mfa_codes.delete_one({"user_id": current_user["id"], "type": "setup"})
            return {"message": "Email MFA enabled successfully"}
        
        # First time - send code
        background_tasks.add_task(send_otp_email, current_user["email"], otp_code)
        return {"message": "Verification code sent to your email. Submit again with the code to enable MFA."}

@mfa_router.post("/disable")
async def disable_mfa(current_user: dict = Depends(get_current_user)):
    await db.users.update_one(
        {"id": current_user["id"]},
        {"$set": {
            "mfa_enabled": False,
            "mfa_method": None,
            "totp_secret": None,
            "pending_totp_secret": None
        }}
    )
    return {"message": "MFA disabled successfully"}

@mfa_router.get("/status")
async def get_mfa_status(current_user: dict = Depends(get_current_user)):
    return {
        "mfa_enabled": current_user.get("mfa_enabled", False),
        "mfa_method": current_user.get("mfa_method")
    }

@mfa_router.post("/resend-code")
async def resend_mfa_code(mfa_token: str, background_tasks: BackgroundTasks):
    try:
        payload = jwt.decode(mfa_token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        token_type = payload.get("type")
        
        if not user_id or token_type != "mfa":
            raise HTTPException(status_code=401, detail="Invalid MFA token")
        
        user = await db.users.find_one({"id": user_id}, {"_id": 0})
        if not user or user.get("mfa_method") != "email":
            raise HTTPException(status_code=400, detail="Email MFA not enabled")
        
        # Generate and send new OTP
        otp_code = generate_otp_code()
        await db.mfa_codes.update_one(
            {"user_id": user_id},
            {"$set": {
                "code": otp_code,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
            }},
            upsert=True
        )
        background_tasks.add_task(send_otp_email, user["email"], otp_code)
        
        return {"message": "New verification code sent"}
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="MFA session expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid MFA token")

# ==================== CLIENTS ROUTES ====================

@clients_router.post("", response_model=ClientResponse)
async def create_client(client: ClientCreate, current_user: dict = Depends(get_current_user)):
    # Validate tier
    if client.tier not in CLIENT_TIERS:
        raise HTTPException(status_code=400, detail=f"Invalid tier. Must be one of: {CLIENT_TIERS}")
    
    client_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    
    client_doc = {
        "id": client_id,
        "user_id": current_user["id"],
        "company_name": client.company_name,
        "poc_name": client.poc_name,
        "poc_email": client.poc_email,
        "notes": client.notes or "",
        "tier": client.tier,
        "created_at": now,
        "updated_at": now
    }
    
    await db.clients.insert_one(client_doc)
    
    return ClientResponse(
        id=client_id,
        company_name=client.company_name,
        poc_name=client.poc_name,
        poc_email=client.poc_email,
        notes=client.notes or "",
        tier=client.tier,
        created_at=now,
        updated_at=now
    )

@clients_router.get("", response_model=List[ClientResponse])
async def get_clients(
    tier: Optional[str] = None,
    search: Optional[str] = None,
    current_user: dict = Depends(get_current_user)
):
    query = {"user_id": current_user["id"]}
    
    if tier:
        query["tier"] = tier
    
    if search:
        query["$or"] = [
            {"company_name": {"$regex": search, "$options": "i"}},
            {"poc_name": {"$regex": search, "$options": "i"}},
            {"poc_email": {"$regex": search, "$options": "i"}}
        ]
    
    clients = await db.clients.find(query, {"_id": 0}).sort("company_name", 1).to_list(1000)
    
    return [ClientResponse(**c) for c in clients]

@clients_router.get("/{client_id}", response_model=ClientResponse)
async def get_client(client_id: str, current_user: dict = Depends(get_current_user)):
    client = await db.clients.find_one(
        {"id": client_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    return ClientResponse(**client)

@clients_router.put("/{client_id}", response_model=ClientResponse)
async def update_client(
    client_id: str,
    update: ClientUpdate,
    current_user: dict = Depends(get_current_user)
):
    client = await db.clients.find_one(
        {"id": client_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    
    if "tier" in update_data and update_data["tier"] not in CLIENT_TIERS:
        raise HTTPException(status_code=400, detail=f"Invalid tier. Must be one of: {CLIENT_TIERS}")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.clients.update_one(
        {"id": client_id},
        {"$set": update_data}
    )
    
    updated_client = await db.clients.find_one({"id": client_id}, {"_id": 0})
    return ClientResponse(**updated_client)

@clients_router.delete("/{client_id}")
async def delete_client(client_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.clients.delete_one(
        {"id": client_id, "user_id": current_user["id"]}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Client not found")
    
    # Also delete associated projects
    await db.projects.delete_many({"client_id": client_id})
    
    return {"message": "Client deleted successfully"}

# ==================== PROJECTS ROUTES ====================

@projects_router.post("", response_model=ProjectResponse)
async def create_project(project: ProjectCreate, current_user: dict = Depends(get_current_user)):
    # Verify client belongs to user
    client = await db.clients.find_one(
        {"id": project.client_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    
    if project.status not in PROJECT_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid status")
    
    if project.priority not in PRIORITY_LEVELS:
        raise HTTPException(status_code=400, detail="Invalid priority")
    
    project_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    
    project_doc = {
        "id": project_id,
        "user_id": current_user["id"],
        "client_id": project.client_id,
        "name": project.name,
        "description": project.description or "",
        "status": project.status,
        "priority": project.priority,
        "due_date": project.due_date,
        "notes": project.notes or "",
        "created_at": now,
        "updated_at": now
    }
    
    await db.projects.insert_one(project_doc)
    
    return ProjectResponse(
        id=project_id,
        client_id=project.client_id,
        client_name=client["company_name"],
        name=project.name,
        description=project.description or "",
        status=project.status,
        priority=project.priority,
        due_date=project.due_date,
        notes=project.notes or "",
        created_at=now,
        updated_at=now
    )

@projects_router.get("", response_model=List[ProjectResponse])
async def get_projects(
    client_id: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    overdue: Optional[bool] = None,
    current_user: dict = Depends(get_current_user)
):
    query = {"user_id": current_user["id"]}
    
    if client_id:
        query["client_id"] = client_id
    if status:
        query["status"] = status
    if priority:
        query["priority"] = priority
    
    projects = await db.projects.find(query, {"_id": 0}).sort("due_date", 1).to_list(1000)
    
    # Get client names
    client_ids = list(set(p["client_id"] for p in projects))
    clients = await db.clients.find(
        {"id": {"$in": client_ids}},
        {"_id": 0, "id": 1, "company_name": 1}
    ).to_list(1000)
    client_map = {c["id"]: c["company_name"] for c in clients}
    
    now = datetime.now(timezone.utc).isoformat()
    
    result = []
    for p in projects:
        if overdue is True:
            if p["due_date"] >= now or p["status"] in ["Completed", "Issued"]:
                continue
        elif overdue is False:
            if p["due_date"] < now and p["status"] not in ["Completed", "Issued"]:
                continue
        
        result.append(ProjectResponse(
            **p,
            client_name=client_map.get(p["client_id"], "Unknown")
        ))
    
    return result

@projects_router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, current_user: dict = Depends(get_current_user)):
    project = await db.projects.find_one(
        {"id": project_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    client = await db.clients.find_one({"id": project["client_id"]}, {"_id": 0})
    
    return ProjectResponse(
        **project,
        client_name=client["company_name"] if client else "Unknown"
    )

@projects_router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    update: ProjectUpdate,
    current_user: dict = Depends(get_current_user)
):
    project = await db.projects.find_one(
        {"id": project_id, "user_id": current_user["id"]},
        {"_id": 0}
    )
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    
    if "status" in update_data and update_data["status"] not in PROJECT_STATUSES:
        raise HTTPException(status_code=400, detail="Invalid status")
    if "priority" in update_data and update_data["priority"] not in PRIORITY_LEVELS:
        raise HTTPException(status_code=400, detail="Invalid priority")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.projects.update_one(
        {"id": project_id},
        {"$set": update_data}
    )
    
    updated = await db.projects.find_one({"id": project_id}, {"_id": 0})
    client = await db.clients.find_one({"id": updated["client_id"]}, {"_id": 0})
    
    return ProjectResponse(
        **updated,
        client_name=client["company_name"] if client else "Unknown"
    )

@projects_router.delete("/{project_id}")
async def delete_project(project_id: str, current_user: dict = Depends(get_current_user)):
    result = await db.projects.delete_one(
        {"id": project_id, "user_id": current_user["id"]}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted successfully"}

# ==================== EMAIL ROUTES ====================

@email_router.get("/settings", response_model=EmailSettingsResponse)
async def get_email_settings(current_user: dict = Depends(get_current_user)):
    settings = await db.email_settings.find_one(
        {"user_id": current_user["id"]},
        {"_id": 0}
    )
    if not settings:
        # Return default settings
        settings_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        settings = {
            "id": settings_id,
            "user_id": current_user["id"],
            "enabled": False,
            "frequency": "weekly",
            "day_of_week": "Monday",
            "time_of_day": "09:00",
            "recipients": [],
            "last_sent": None,
            "updated_at": now
        }
        await db.email_settings.insert_one(settings)
    
    return EmailSettingsResponse(**settings)

@email_router.put("/settings", response_model=EmailSettingsResponse)
async def update_email_settings(
    settings_data: EmailSettingsCreate,
    current_user: dict = Depends(get_current_user)
):
    now = datetime.now(timezone.utc).isoformat()
    
    existing = await db.email_settings.find_one({"user_id": current_user["id"]})
    
    if existing:
        await db.email_settings.update_one(
            {"user_id": current_user["id"]},
            {"$set": {
                **settings_data.model_dump(),
                "updated_at": now
            }}
        )
        updated = await db.email_settings.find_one(
            {"user_id": current_user["id"]},
            {"_id": 0}
        )
    else:
        settings_id = str(uuid.uuid4())
        updated = {
            "id": settings_id,
            "user_id": current_user["id"],
            **settings_data.model_dump(),
            "last_sent": None,
            "updated_at": now
        }
        await db.email_settings.insert_one(updated)
    
    return EmailSettingsResponse(**updated)

@email_router.post("/send-test")
async def send_test_email(
    recipient: EmailStr,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    if not SMTP_USER or not SMTP_PASSWORD:
        raise HTTPException(status_code=400, detail="Email not configured. Please set SMTP credentials.")
    
    background_tasks.add_task(send_email_notification, recipient, current_user["id"], is_test=True)
    return {"message": "Test email queued for sending"}

@email_router.post("/send-weekly")
async def trigger_weekly_email(
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_user)
):
    settings = await db.email_settings.find_one({"user_id": current_user["id"]})
    if not settings or not settings.get("recipients"):
        raise HTTPException(status_code=400, detail="No recipients configured")
    
    for recipient in settings["recipients"]:
        background_tasks.add_task(send_email_notification, recipient, current_user["id"], is_test=False)
    
    return {"message": f"Weekly email queued for {len(settings['recipients'])} recipients"}

async def send_email_notification(recipient: str, user_id: str, is_test: bool = False):
    try:
        # Get upcoming deadlines
        now = datetime.now(timezone.utc)
        one_week = now + timedelta(days=7)
        
        projects = await db.projects.find({
            "user_id": user_id,
            "status": {"$nin": ["Completed", "Issued"]},
            "due_date": {"$lte": one_week.isoformat()}
        }, {"_id": 0}).sort("due_date", 1).to_list(100)
        
        # Get client names
        client_ids = list(set(p["client_id"] for p in projects))
        clients = await db.clients.find(
            {"id": {"$in": client_ids}},
            {"_id": 0, "id": 1, "company_name": 1}
        ).to_list(100)
        client_map = {c["id"]: c["company_name"] for c in clients}
        
        # Build email content
        html = build_email_html(projects, client_map, is_test)
        
        # Send email
        msg = MIMEMultipart("alternative")
        msg["From"] = f"{SMTP_FROM_NAME} <{SMTP_FROM_EMAIL}>"
        msg["To"] = recipient
        msg["Subject"] = "Test Email - Project Management" if is_test else "Weekly Deadline Reminder"
        msg.attach(MIMEText(html, "html"))
        
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        
        # Log email
        await db.email_logs.insert_one({
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "recipient": recipient,
            "subject": msg["Subject"],
            "status": "sent",
            "sent_at": datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"Email sent to {recipient}")
        
    except Exception as e:
        logger.error(f"Failed to send email to {recipient}: {str(e)}")
        await db.email_logs.insert_one({
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "recipient": recipient,
            "status": "failed",
            "error": str(e),
            "sent_at": datetime.now(timezone.utc).isoformat()
        })

def build_email_html(projects: List[dict], client_map: dict, is_test: bool) -> str:
    now = datetime.now(timezone.utc).isoformat()
    
    overdue = [p for p in projects if p["due_date"] < now]
    due_soon = [p for p in projects if p["due_date"] >= now]
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: 'IBM Plex Sans', Arial, sans-serif; margin: 0; padding: 20px; background: #f1f5f9; }}
            .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; }}
            .header {{ background: #0f172a; color: white; padding: 24px; }}
            .header h1 {{ margin: 0; font-family: 'Chivo', Arial, sans-serif; }}
            .content {{ padding: 24px; }}
            .section {{ margin-bottom: 24px; }}
            .section-title {{ font-size: 14px; font-weight: 600; color: #64748b; text-transform: uppercase; margin-bottom: 12px; }}
            .project {{ border-left: 4px solid #3b82f6; background: #f8fafc; padding: 12px; margin-bottom: 8px; border-radius: 0 4px 4px 0; }}
            .project.overdue {{ border-left-color: #f43f5e; }}
            .project-name {{ font-weight: 600; color: #0f172a; }}
            .project-client {{ color: #64748b; font-size: 14px; }}
            .project-meta {{ display: flex; gap: 16px; margin-top: 8px; font-size: 12px; }}
            .badge {{ display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }}
            .badge-overdue {{ background: #fee2e2; color: #dc2626; }}
            .badge-due {{ background: #fef3c7; color: #d97706; }}
            .footer {{ background: #f8fafc; padding: 16px 24px; text-align: center; color: #64748b; font-size: 12px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{"Test Email" if is_test else "Weekly Deadline Reminder"}</h1>
                <p style="margin: 8px 0 0 0; opacity: 0.8;">Upcoming project deadlines</p>
            </div>
            <div class="content">
    """
    
    if overdue:
        html += f"""
                <div class="section">
                    <div class="section-title">Overdue ({len(overdue)})</div>
        """
        for p in overdue[:10]:
            html += f"""
                    <div class="project overdue">
                        <div class="project-name">{p['name']}</div>
                        <div class="project-client">{client_map.get(p['client_id'], 'Unknown Client')}</div>
                        <div class="project-meta">
                            <span class="badge badge-overdue">OVERDUE</span>
                            <span>Due: {p['due_date'][:10]}</span>
                            <span>Priority: {p['priority']}</span>
                        </div>
                    </div>
            """
        html += "</div>"
    
    if due_soon:
        html += f"""
                <div class="section">
                    <div class="section-title">Due This Week ({len(due_soon)})</div>
        """
        for p in due_soon[:10]:
            html += f"""
                    <div class="project">
                        <div class="project-name">{p['name']}</div>
                        <div class="project-client">{client_map.get(p['client_id'], 'Unknown Client')}</div>
                        <div class="project-meta">
                            <span class="badge badge-due">{p['status']}</span>
                            <span>Due: {p['due_date'][:10]}</span>
                            <span>Priority: {p['priority']}</span>
                        </div>
                    </div>
            """
        html += "</div>"
    
    if not overdue and not due_soon:
        html += """
                <div class="section" style="text-align: center; padding: 40px 0;">
                    <p style="color: #10b981; font-weight: 600;">No upcoming deadlines!</p>
                    <p style="color: #64748b;">All projects are on track.</p>
                </div>
        """
    
    html += """
            </div>
            <div class="footer">
                <p>This is an automated email from your Project Management System</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return html

@email_router.get("/logs")
async def get_email_logs(current_user: dict = Depends(get_current_user)):
    logs = await db.email_logs.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("sent_at", -1).to_list(50)
    return logs

# ==================== DASHBOARD ROUTES ====================

@dashboard_router.get("/stats", response_model=DashboardStats)
async def get_dashboard_stats(current_user: dict = Depends(get_current_user)):
    user_id = current_user["id"]
    now = datetime.now(timezone.utc).isoformat()
    one_week = (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()
    
    # Get counts
    total_clients = await db.clients.count_documents({"user_id": user_id})
    total_projects = await db.projects.count_documents({"user_id": user_id})
    
    # Projects by status
    status_pipeline = [
        {"$match": {"user_id": user_id}},
        {"$group": {"_id": "$status", "count": {"$sum": 1}}}
    ]
    status_results = await db.projects.aggregate(status_pipeline).to_list(100)
    projects_by_status = {r["_id"]: r["count"] for r in status_results}
    
    # Projects by priority
    priority_pipeline = [
        {"$match": {"user_id": user_id}},
        {"$group": {"_id": "$priority", "count": {"$sum": 1}}}
    ]
    priority_results = await db.projects.aggregate(priority_pipeline).to_list(10)
    projects_by_priority = {r["_id"]: r["count"] for r in priority_results}
    
    # Overdue projects
    overdue_projects = await db.projects.count_documents({
        "user_id": user_id,
        "due_date": {"$lt": now},
        "status": {"$nin": ["Completed", "Issued"]}
    })
    
    # Due this week
    due_this_week = await db.projects.count_documents({
        "user_id": user_id,
        "due_date": {"$gte": now, "$lte": one_week},
        "status": {"$nin": ["Completed", "Issued"]}
    })
    
    # Clients by tier
    tier_pipeline = [
        {"$match": {"user_id": user_id}},
        {"$group": {"_id": "$tier", "count": {"$sum": 1}}}
    ]
    tier_results = await db.clients.aggregate(tier_pipeline).to_list(10)
    clients_by_tier = {r["_id"]: r["count"] for r in tier_results}
    
    return DashboardStats(
        total_clients=total_clients,
        total_projects=total_projects,
        projects_by_status=projects_by_status,
        projects_by_priority=projects_by_priority,
        overdue_projects=overdue_projects,
        due_this_week=due_this_week,
        clients_by_tier=clients_by_tier
    )

@dashboard_router.get("/upcoming")
async def get_upcoming_deadlines(
    days: int = 7,
    current_user: dict = Depends(get_current_user)
):
    now = datetime.now(timezone.utc).isoformat()
    future = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()
    
    projects = await db.projects.find({
        "user_id": current_user["id"],
        "due_date": {"$gte": now, "$lte": future},
        "status": {"$nin": ["Completed", "Issued"]}
    }, {"_id": 0}).sort("due_date", 1).to_list(50)
    
    # Get client names
    client_ids = list(set(p["client_id"] for p in projects))
    clients = await db.clients.find(
        {"id": {"$in": client_ids}},
        {"_id": 0, "id": 1, "company_name": 1}
    ).to_list(100)
    client_map = {c["id"]: c["company_name"] for c in clients}
    
    return [{**p, "client_name": client_map.get(p["client_id"], "Unknown")} for p in projects]

@dashboard_router.get("/overdue")
async def get_overdue_projects(current_user: dict = Depends(get_current_user)):
    now = datetime.now(timezone.utc).isoformat()
    
    projects = await db.projects.find({
        "user_id": current_user["id"],
        "due_date": {"$lt": now},
        "status": {"$nin": ["Completed", "Issued"]}
    }, {"_id": 0}).sort("due_date", 1).to_list(50)
    
    # Get client names
    client_ids = list(set(p["client_id"] for p in projects))
    clients = await db.clients.find(
        {"id": {"$in": client_ids}},
        {"_id": 0, "id": 1, "company_name": 1}
    ).to_list(100)
    client_map = {c["id"]: c["company_name"] for c in clients}
    
    return [{**p, "client_name": client_map.get(p["client_id"], "Unknown")} for p in projects]

# ==================== CONFIG ROUTES ====================

@api_router.get("/config/statuses")
async def get_statuses():
    return {"statuses": PROJECT_STATUSES}

@api_router.get("/config/priorities")
async def get_priorities():
    return {"priorities": PRIORITY_LEVELS}

@api_router.get("/config/tiers")
async def get_tiers():
    return {"tiers": CLIENT_TIERS}

@api_router.get("/")
async def root():
    return {"message": "Client Project Management API"}

# ==================== BULK UPLOAD ROUTES ====================

@bulk_router.get("/template")
async def download_template(current_user: dict = Depends(get_current_user)):
    """Generate and download Excel template for bulk client/project upload"""
    wb = Workbook()
    
    # Clients Sheet
    ws_clients = wb.active
    ws_clients.title = "Clients"
    
    client_headers = ["Company Name*", "POC Name*", "POC Email*", "Tier", "Notes"]
    header_fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for col, header in enumerate(client_headers, 1):
        cell = ws_clients.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border
        ws_clients.column_dimensions[get_column_letter(col)].width = 20
    
    # Add sample data row
    sample_client = ["Acme Corporation", "John Smith", "john@acme.com", "Tier 1", "Major client"]
    for col, value in enumerate(sample_client, 1):
        cell = ws_clients.cell(row=2, column=col, value=value)
        cell.border = thin_border
        cell.font = Font(italic=True, color="666666")
    
    # Add tier options as data validation note
    ws_clients.cell(row=4, column=1, value="Valid Tiers: Tier 1, Tier 2, Tier 3")
    ws_clients.cell(row=4, column=1).font = Font(italic=True, color="888888")
    
    # Projects Sheet
    ws_projects = wb.create_sheet("Projects")
    
    project_headers = ["Client Company Name*", "Project Name*", "Status", "Priority", "Due Date* (YYYY-MM-DD)", "Description", "Notes"]
    
    for col, header in enumerate(project_headers, 1):
        cell = ws_projects.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border
        ws_projects.column_dimensions[get_column_letter(col)].width = 25
    
    # Add sample project
    sample_project = ["Acme Corporation", "Q4 2025 Audit", "Planning Calls Scheduled", "High", "2026-03-15", "Annual audit", ""]
    for col, value in enumerate(sample_project, 1):
        cell = ws_projects.cell(row=2, column=col, value=value)
        cell.border = thin_border
        cell.font = Font(italic=True, color="666666")
    
    # Add status options
    ws_projects.cell(row=4, column=1, value="Valid Statuses:")
    ws_projects.cell(row=4, column=1).font = Font(bold=True)
    for i, status in enumerate(PROJECT_STATUSES, 5):
        ws_projects.cell(row=i, column=1, value=status)
        ws_projects.cell(row=i, column=1).font = Font(italic=True, color="888888")
    
    ws_projects.cell(row=4, column=3, value="Valid Priorities: Low, Medium, High, Critical")
    ws_projects.cell(row=4, column=3).font = Font(italic=True, color="888888")
    
    # Instructions Sheet
    ws_instructions = wb.create_sheet("Instructions")
    instructions = [
        ("Bulk Upload Instructions", True),
        ("", False),
        ("1. Fill in the 'Clients' sheet with your client data", False),
        ("2. Fill in the 'Projects' sheet with project data", False),
        ("3. Fields marked with * are required", False),
        ("4. The 'Client Company Name' in Projects must match exactly with a company in Clients sheet", False),
        ("5. Delete the sample rows (row 2) before uploading", False),
        ("6. Save the file and upload it through the application", False),
        ("", False),
        ("Notes:", True),
        ("- Existing clients with the same email will be updated", False),
        ("- New clients will be created", False),
        ("- Projects will be linked to clients by company name", False),
    ]
    
    for row, (text, is_bold) in enumerate(instructions, 1):
        cell = ws_instructions.cell(row=row, column=1, value=text)
        if is_bold:
            cell.font = Font(bold=True, size=14)
    ws_instructions.column_dimensions['A'].width = 80
    
    # Save to bytes
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=client_project_template.xlsx"}
    )

class BulkUploadResult(BaseModel):
    clients_created: int
    clients_updated: int
    projects_created: int
    errors: List[str]

@bulk_router.post("/upload", response_model=BulkUploadResult)
async def bulk_upload(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """Process bulk upload of clients and projects from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Please upload an Excel file (.xlsx or .xls)")
    
    try:
        contents = await file.read()
        wb = load_workbook(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read Excel file: {str(e)}")
    
    errors = []
    clients_created = 0
    clients_updated = 0
    projects_created = 0
    client_map = {}  # Map company name to client id
    
    # Process Clients sheet
    if "Clients" in wb.sheetnames:
        ws_clients = wb["Clients"]
        for row_num, row in enumerate(ws_clients.iter_rows(min_row=2, values_only=True), 2):
            if not row or not row[0]:  # Skip empty rows
                continue
            
            company_name, poc_name, poc_email, tier, notes = (
                str(row[0]).strip() if row[0] else None,
                str(row[1]).strip() if len(row) > 1 and row[1] else None,
                str(row[2]).strip() if len(row) > 2 and row[2] else None,
                str(row[3]).strip() if len(row) > 3 and row[3] else "Tier 2",
                str(row[4]).strip() if len(row) > 4 and row[4] else ""
            )
            
            # Skip sample row
            if company_name == "Acme Corporation" and poc_email == "john@acme.com":
                continue
            
            if not all([company_name, poc_name, poc_email]):
                errors.append(f"Clients row {row_num}: Missing required fields")
                continue
            
            if tier not in CLIENT_TIERS:
                tier = "Tier 2"
            
            # Check if client exists
            existing = await db.clients.find_one({
                "user_id": current_user["id"],
                "poc_email": poc_email
            })
            
            now = datetime.now(timezone.utc).isoformat()
            
            if existing:
                await db.clients.update_one(
                    {"id": existing["id"]},
                    {"$set": {
                        "company_name": company_name,
                        "poc_name": poc_name,
                        "tier": tier,
                        "notes": notes,
                        "updated_at": now
                    }}
                )
                client_map[company_name] = existing["id"]
                clients_updated += 1
            else:
                client_id = str(uuid.uuid4())
                await db.clients.insert_one({
                    "id": client_id,
                    "user_id": current_user["id"],
                    "company_name": company_name,
                    "poc_name": poc_name,
                    "poc_email": poc_email,
                    "tier": tier,
                    "notes": notes,
                    "created_at": now,
                    "updated_at": now
                })
                client_map[company_name] = client_id
                clients_created += 1
    
    # Also load existing clients for project linking
    existing_clients = await db.clients.find(
        {"user_id": current_user["id"]},
        {"_id": 0, "id": 1, "company_name": 1}
    ).to_list(1000)
    for c in existing_clients:
        if c["company_name"] not in client_map:
            client_map[c["company_name"]] = c["id"]
    
    # Process Projects sheet
    if "Projects" in wb.sheetnames:
        ws_projects = wb["Projects"]
        for row_num, row in enumerate(ws_projects.iter_rows(min_row=2, values_only=True), 2):
            if not row or not row[0]:
                continue
            
            client_company, project_name, status, priority, due_date, description, notes = (
                str(row[0]).strip() if row[0] else None,
                str(row[1]).strip() if len(row) > 1 and row[1] else None,
                str(row[2]).strip() if len(row) > 2 and row[2] else "Planning Calls Scheduled",
                str(row[3]).strip() if len(row) > 3 and row[3] else "Medium",
                str(row[4]).strip() if len(row) > 4 and row[4] else None,
                str(row[5]).strip() if len(row) > 5 and row[5] else "",
                str(row[6]).strip() if len(row) > 6 and row[6] else ""
            )
            
            # Skip sample row
            if client_company == "Acme Corporation" and project_name == "Q4 2025 Audit":
                continue
            
            if not all([client_company, project_name, due_date]):
                errors.append(f"Projects row {row_num}: Missing required fields")
                continue
            
            if client_company not in client_map:
                errors.append(f"Projects row {row_num}: Client '{client_company}' not found")
                continue
            
            if status not in PROJECT_STATUSES:
                status = "Planning Calls Scheduled"
            
            if priority not in PRIORITY_LEVELS:
                priority = "Medium"
            
            now = datetime.now(timezone.utc).isoformat()
            project_id = str(uuid.uuid4())
            
            await db.projects.insert_one({
                "id": project_id,
                "user_id": current_user["id"],
                "client_id": client_map[client_company],
                "name": project_name,
                "description": description,
                "status": status,
                "priority": priority,
                "due_date": due_date,
                "notes": notes,
                "created_at": now,
                "updated_at": now
            })
            projects_created += 1
    
    return BulkUploadResult(
        clients_created=clients_created,
        clients_updated=clients_updated,
        projects_created=projects_created,
        errors=errors
    )

# ==================== HUBSPOT ROUTES ====================

class HubSpotConfig(BaseModel):
    api_key: str

@hubspot_router.post("/configure")
async def configure_hubspot(
    config: HubSpotConfig,
    current_user: dict = Depends(get_current_user)
):
    """Save HubSpot API key for the user"""
    await db.hubspot_config.update_one(
        {"user_id": current_user["id"]},
        {"$set": {
            "user_id": current_user["id"],
            "api_key": config.api_key,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }},
        upsert=True
    )
    return {"message": "HubSpot API key configured successfully"}

@hubspot_router.get("/status")
async def get_hubspot_status(current_user: dict = Depends(get_current_user)):
    """Check if HubSpot is configured"""
    config = await db.hubspot_config.find_one({"user_id": current_user["id"]})
    return {
        "configured": bool(config and config.get("api_key")),
        "updated_at": config.get("updated_at") if config else None
    }

async def get_hubspot_client(user_id: str):
    """Get HubSpot API key for a user"""
    config = await db.hubspot_config.find_one({"user_id": user_id})
    if not config or not config.get("api_key"):
        raise HTTPException(status_code=400, detail="HubSpot not configured. Please add your API key.")
    return config["api_key"]

@hubspot_router.get("/contacts")
async def get_hubspot_contacts(
    limit: int = 50,
    current_user: dict = Depends(get_current_user)
):
    """Fetch contacts from HubSpot"""
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/contacts",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 100),
                "properties": "firstname,lastname,email,phone,company,lifecyclestage"
            },
            timeout=30.0
        )
        
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch HubSpot contacts")
        
        return response.json()

@hubspot_router.get("/companies")
async def get_hubspot_companies(
    limit: int = 50,
    current_user: dict = Depends(get_current_user)
):
    """Fetch companies from HubSpot"""
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/companies",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 100),
                "properties": "name,domain,industry,annualrevenue,numberofemployees"
            },
            timeout=30.0
        )
        
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch HubSpot companies")
        
        return response.json()

@hubspot_router.get("/deals")
async def get_hubspot_deals(
    limit: int = 50,
    current_user: dict = Depends(get_current_user)
):
    """Fetch deals from HubSpot"""
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/deals",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 100),
                "properties": "dealname,dealstage,pipeline,amount,closedate,hubspot_owner_id"
            },
            timeout=30.0
        )
        
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch HubSpot deals")
        
        return response.json()

@hubspot_router.get("/pipelines")
async def get_hubspot_pipelines(current_user: dict = Depends(get_current_user)):
    """Fetch deal pipelines from HubSpot"""
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/pipelines/deals",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0
        )
        
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail="Failed to fetch HubSpot pipelines")
        
        return response.json()

@hubspot_router.get("/pipeline-summary")
async def get_hubspot_pipeline_summary(current_user: dict = Depends(get_current_user)):
    """Get deal pipeline summary for dashboard"""
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        # Fetch pipelines
        pipelines_response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/pipelines/deals",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0
        )
        
        if pipelines_response.status_code != 200:
            raise HTTPException(status_code=pipelines_response.status_code, detail="Failed to fetch pipelines")
        
        pipelines_data = pipelines_response.json()
        
        # Fetch all deals
        deals_response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/deals",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": 100,
                "properties": "dealname,dealstage,pipeline,amount,closedate"
            },
            timeout=30.0
        )
        
        if deals_response.status_code != 200:
            raise HTTPException(status_code=deals_response.status_code, detail="Failed to fetch deals")
        
        deals_data = deals_response.json()
        
        # Build pipeline summary
        summary = []
        for pipeline in pipelines_data.get("results", []):
            pipeline_id = pipeline["id"]
            pipeline_label = pipeline["label"]
            
            stages_summary = []
            for stage in pipeline.get("stages", []):
                stage_id = stage["id"]
                stage_label = stage["label"]
                
                # Count deals in this stage
                stage_deals = [
                    d for d in deals_data.get("results", [])
                    if d["properties"].get("pipeline") == pipeline_id 
                    and d["properties"].get("dealstage") == stage_id
                ]
                
                total_amount = sum(
                    float(d["properties"].get("amount") or 0)
                    for d in stage_deals
                )
                
                stages_summary.append({
                    "id": stage_id,
                    "label": stage_label,
                    "deal_count": len(stage_deals),
                    "total_amount": total_amount,
                    "probability": stage.get("metadata", {}).get("probability")
                })
            
            summary.append({
                "id": pipeline_id,
                "label": pipeline_label,
                "stages": stages_summary,
                "total_deals": sum(s["deal_count"] for s in stages_summary),
                "total_value": sum(s["total_amount"] for s in stages_summary)
            })
        
        return {"pipelines": summary}

@hubspot_router.get("/activities")
async def get_hubspot_activities(
    limit: int = 20,
    current_user: dict = Depends(get_current_user)
):
    """Fetch recent activities (tasks, calls, emails, meetings) from HubSpot"""
    api_key = await get_hubspot_client(current_user["id"])
    
    activities = []
    
    async with httpx.AsyncClient() as client:
        # Fetch tasks
        tasks_response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/tasks",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 50),
                "properties": "hs_task_subject,hs_task_body,hs_task_status,hs_task_priority,hs_timestamp"
            },
            timeout=30.0
        )
        
        if tasks_response.status_code == 200:
            for task in tasks_response.json().get("results", []):
                activities.append({
                    "id": task["id"],
                    "type": "task",
                    "subject": task["properties"].get("hs_task_subject"),
                    "body": task["properties"].get("hs_task_body"),
                    "status": task["properties"].get("hs_task_status"),
                    "priority": task["properties"].get("hs_task_priority"),
                    "timestamp": task["properties"].get("hs_timestamp"),
                    "created_at": task["createdAt"],
                    "updated_at": task["updatedAt"]
                })
        
        # Fetch calls
        calls_response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/calls",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 50),
                "properties": "hs_call_title,hs_call_body,hs_call_status,hs_call_direction,hs_timestamp"
            },
            timeout=30.0
        )
        
        if calls_response.status_code == 200:
            for call in calls_response.json().get("results", []):
                activities.append({
                    "id": call["id"],
                    "type": "call",
                    "subject": call["properties"].get("hs_call_title"),
                    "body": call["properties"].get("hs_call_body"),
                    "status": call["properties"].get("hs_call_status"),
                    "direction": call["properties"].get("hs_call_direction"),
                    "timestamp": call["properties"].get("hs_timestamp"),
                    "created_at": call["createdAt"],
                    "updated_at": call["updatedAt"]
                })
        
        # Fetch emails
        emails_response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/objects/emails",
            headers={"Authorization": f"Bearer {api_key}"},
            params={
                "limit": min(limit, 50),
                "properties": "hs_email_subject,hs_email_text,hs_email_status,hs_email_direction,hs_timestamp"
            },
            timeout=30.0
        )
        
        if emails_response.status_code == 200:
            for email in emails_response.json().get("results", []):
                activities.append({
                    "id": email["id"],
                    "type": "email",
                    "subject": email["properties"].get("hs_email_subject"),
                    "body": email["properties"].get("hs_email_text"),
                    "status": email["properties"].get("hs_email_status"),
                    "direction": email["properties"].get("hs_email_direction"),
                    "timestamp": email["properties"].get("hs_timestamp"),
                    "created_at": email["createdAt"],
                    "updated_at": email["updatedAt"]
                })
    
    # Sort by updated_at descending
    activities.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
    
    return {"activities": activities[:limit]}

@hubspot_router.get("/properties/{object_type}")
async def get_hubspot_properties(
    object_type: str,
    current_user: dict = Depends(get_current_user)
):
    """Get all properties (including custom) for an object type"""
    if object_type not in ["contacts", "companies", "deals", "tasks"]:
        raise HTTPException(status_code=400, detail="Invalid object type")
    
    api_key = await get_hubspot_client(current_user["id"])
    
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{HUBSPOT_BASE_URL}/crm/v3/properties/{object_type}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0
        )
        
        if response.status_code != 200:
            raise HTTPException(status_code=response.status_code, detail=f"Failed to fetch {object_type} properties")
        
        data = response.json()
        
        # Group by category
        grouped = {}
        for prop in data.get("results", []):
            group = prop.get("groupName", "other")
            if group not in grouped:
                grouped[group] = []
            grouped[group].append({
                "name": prop.get("name"),
                "label": prop.get("label"),
                "type": prop.get("type"),
                "fieldType": prop.get("fieldType"),
                "description": prop.get("description"),
                "hidden": prop.get("hidden", False),
                "options": prop.get("options", [])
            })
        
        return {"properties": grouped}

# Include routers
app.include_router(api_router)
app.include_router(auth_router)
app.include_router(mfa_router)
app.include_router(clients_router)
app.include_router(projects_router)
app.include_router(email_router)
app.include_router(dashboard_router)
app.include_router(bulk_router)
app.include_router(hubspot_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
