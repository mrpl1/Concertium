import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { projectsApi } from '@/lib/api';
import { 
  cn, 
  getStatusClass, 
  getPriorityClass, 
  formatDate,
  isOverdue 
} from '@/lib/utils';
import { CalendarDays, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

export default function CalendarPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const res = await projectsApi.getAll();
      setProjects(res.data.filter(p => p.status !== 'Completed' && p.status !== 'Issued'));
    } catch (error) {
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  // Get projects due on selected date
  const selectedDateStr = selectedDate.toISOString().split('T')[0];
  const projectsOnDate = projects.filter(p => p.due_date.split('T')[0] === selectedDateStr);

  // Get all dates with projects for highlighting
  const projectDates = projects.reduce((acc, p) => {
    const dateStr = p.due_date.split('T')[0];
    if (!acc[dateStr]) acc[dateStr] = [];
    acc[dateStr].push(p);
    return acc;
  }, {});

  // Custom day content to show indicators
  const modifiers = {
    hasProjects: Object.keys(projectDates).map(d => new Date(d)),
    overdue: projects.filter(p => isOverdue(p.due_date)).map(p => new Date(p.due_date))
  };

  const modifiersStyles = {
    hasProjects: {
      fontWeight: 'bold',
    },
    overdue: {
      color: '#dc2626',
    }
  };

  return (
    <MainLayout title="Calendar">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="calendar-page">
        {/* Calendar */}
        <Card className="lg:col-span-2 border border-slate-200 shadow-sm" data-testid="calendar-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <CalendarDays className="w-4 h-4" />
              Due Dates Calendar
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
              </div>
            ) : (
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  modifiers={modifiers}
                  modifiersStyles={modifiersStyles}
                  className="rounded-md border"
                  data-testid="project-calendar"
                />
              </div>
            )}
            
            {/* Legend */}
            <div className="mt-4 flex items-center gap-4 justify-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-slate-900"></div>
                <span className="text-slate-600">Has Projects</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                <span className="text-slate-600">Overdue</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Selected Date Projects */}
        <Card className="border border-slate-200 shadow-sm" data-testid="selected-date-projects">
          <CardHeader>
            <CardTitle className="text-base font-semibold">
              {formatDate(selectedDate.toISOString())}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {projectsOnDate.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-8">
                No projects due on this date
              </p>
            ) : (
              <div className="space-y-3">
                {projectsOnDate.map((project) => (
                  <Link
                    key={project.id}
                    to={`/clients/${project.client_id}`}
                    className={cn(
                      "block p-3 rounded-lg border transition-colors",
                      isOverdue(project.due_date) 
                        ? "border-rose-200 bg-rose-50 hover:bg-rose-100" 
                        : "border-slate-200 bg-slate-50 hover:bg-slate-100"
                    )}
                    data-testid={`calendar-project-${project.id}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-slate-900 truncate">
                          {project.name}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5 truncate">
                          {project.client_name}
                        </p>
                      </div>
                      {isOverdue(project.due_date) && (
                        <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className={cn("text-xs", getStatusClass(project.status))}>
                        {project.status}
                      </Badge>
                      <Badge className={cn("text-xs", getPriorityClass(project.priority))}>
                        {project.priority}
                      </Badge>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Projects List */}
        <Card className="lg:col-span-3 border border-slate-200 shadow-sm" data-testid="upcoming-projects-list">
          <CardHeader>
            <CardTitle className="text-base font-semibold">
              All Upcoming Deadlines
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-slate-900"></div>
              </div>
            ) : projects.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-8">
                No upcoming deadlines
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {projects
                  .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
                  .slice(0, 20)
                  .map((project) => (
                    <Link
                      key={project.id}
                      to={`/clients/${project.client_id}`}
                      className={cn(
                        "p-3 rounded-lg border transition-colors",
                        isOverdue(project.due_date) 
                          ? "border-rose-200 bg-rose-50 hover:bg-rose-100" 
                          : "border-slate-200 bg-slate-50 hover:bg-slate-100"
                      )}
                      data-testid={`upcoming-project-${project.id}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className={cn(
                          "text-xs font-medium",
                          isOverdue(project.due_date) ? "text-rose-600" : "text-slate-500"
                        )}>
                          {formatDate(project.due_date)}
                        </span>
                        {isOverdue(project.due_date) && (
                          <Badge variant="destructive" className="text-xs">Overdue</Badge>
                        )}
                      </div>
                      <p className="font-medium text-sm text-slate-900 truncate">
                        {project.name}
                      </p>
                      <p className="text-xs text-slate-500 truncate">
                        {project.client_name}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className={cn("text-xs", getPriorityClass(project.priority))}>
                          {project.priority}
                        </Badge>
                      </div>
                    </Link>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
