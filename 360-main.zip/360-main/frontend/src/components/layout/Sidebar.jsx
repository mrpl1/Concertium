import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  CalendarDays, 
  Mail, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  Shield,
  Upload,
  Boxes
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/clients', label: 'Clients', icon: Users },
  { path: '/projects', label: 'Projects', icon: FolderKanban },
  { path: '/calendar', label: 'Calendar', icon: CalendarDays },
  { path: '/bulk-upload', label: 'Bulk Upload', icon: Upload },
  { path: '/hubspot', label: 'HubSpot', icon: Boxes },
  { path: '/email-settings', label: 'Email Settings', icon: Mail },
  { path: '/security', label: 'Security', icon: Shield },
];

export const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside 
      data-testid="sidebar"
      className={cn(
        "fixed left-0 top-0 h-screen bg-slate-900 text-white flex flex-col z-40 transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Header */}
      <div className={cn(
        "h-16 flex items-center border-b border-slate-700/50 px-4",
        collapsed ? "justify-center" : "justify-between"
      )}>
        {!collapsed && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <FolderKanban className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg font-['Chivo']">ClientHub</span>
          </div>
        )}
        <button
          data-testid="sidebar-toggle"
          onClick={() => setCollapsed(!collapsed)}
          className="p-1 hover:bg-slate-700 rounded transition-colors"
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
              isActive 
                ? "bg-emerald-500/20 text-emerald-400" 
                : "text-slate-300 hover:bg-slate-800 hover:text-white",
              collapsed && "justify-center"
            )}
          >
            <item.icon className="w-5 h-5 shrink-0" />
            {!collapsed && <span className="font-medium">{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* User section */}
      <div className={cn(
        "border-t border-slate-700/50 p-4",
        collapsed && "flex flex-col items-center"
      )}>
        {!collapsed && user && (
          <div className="mb-3">
            <p className="font-medium text-sm truncate">{user.name}</p>
            <p className="text-xs text-slate-400 truncate">{user.email}</p>
          </div>
        )}
        <Button
          data-testid="logout-btn"
          variant="ghost"
          onClick={handleLogout}
          className={cn(
            "text-slate-300 hover:text-white hover:bg-slate-800",
            collapsed ? "w-10 h-10 p-0" : "w-full justify-start"
          )}
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="ml-2">Logout</span>}
        </Button>
      </div>
    </aside>
  );
};
