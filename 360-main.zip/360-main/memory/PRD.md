# Client Project Management System - PRD

## Original Problem Statement
Create a project management system that allows tracking various clients and their associated due dates, with customizable statuses and the ability to send weekly emails with upcoming due dates and deadlines.

## User Personas
- **Primary**: Professional services firm staff (auditors, consultants) managing multiple client engagements
- **Secondary**: Firm managers/directors reviewing project status and deadlines

## Core Requirements (Implemented)

### User Choices
- **Email Provider**: Microsoft Outlook (SMTP)
- **Authentication**: JWT-based custom auth with MFA support
- **MFA Options**: Email OTP and Authenticator App (TOTP)
- **Custom Statuses**: 19 workflow statuses for audit/consulting engagements
- **Client Info**: Company Name, POC Name, POC Email, Notes, Tier (1-3)
- **Additional Features**: Priority levels, Client tiers

## What's Been Implemented

### Feb 3, 2026 - MVP
- JWT Authentication with MFA support
- Client and Project CRUD operations
- Dashboard with stats and deadlines
- Calendar view for due dates
- Email settings configuration
- Security Settings for MFA management

### Feb 4, 2026 - Bulk Upload & HubSpot Integration
- **Excel Bulk Upload Feature**:
  - Download Excel template with Clients and Projects sheets
  - Template includes sample data and instructions
  - Bulk upload processes clients (creates new or updates existing by email)
  - Links projects to clients by company name
  - Returns detailed results with error reporting

- **HubSpot Integration**:
  - Configure HubSpot with Private App Access Token
  - Fetch deal pipeline summary with stage breakdowns
  - Display total deals and value per stage
  - View recent activities (tasks, calls, emails)
  - Support for contacts, companies, deals data
  - Fetch custom properties per object type

### Features by Page
1. **Login/Register** - JWT auth with MFA verification
2. **Dashboard** - Stats cards, overdue alerts, upcoming deadlines
3. **Clients** - List, add, edit, delete, tier filtering
4. **Client Detail** - Client info, projects table, add/edit projects
5. **Projects** - All projects list with status/priority filters
6. **Calendar** - Due dates visualization
7. **Bulk Upload** - Template download, Excel upload processing
8. **HubSpot Dashboard** - Pipeline summary, recent activities
9. **Email Settings** - Weekly email configuration
10. **Security** - MFA setup (TOTP/Email)

## API Endpoints

### Bulk Upload
- `GET /api/bulk/template` - Download Excel template
- `POST /api/bulk/upload` - Process bulk upload file

### HubSpot
- `GET /api/hubspot/status` - Check configuration status
- `POST /api/hubspot/configure` - Save API key
- `GET /api/hubspot/contacts` - Fetch contacts
- `GET /api/hubspot/companies` - Fetch companies
- `GET /api/hubspot/deals` - Fetch deals
- `GET /api/hubspot/pipelines` - Fetch pipelines
- `GET /api/hubspot/pipeline-summary` - Dashboard summary
- `GET /api/hubspot/activities` - Recent activities
- `GET /api/hubspot/properties/{object_type}` - Custom properties

## Prioritized Backlog

### P0 (Critical) - ✅ Complete
- Core CRUD operations
- Authentication with MFA
- Dashboard and Calendar
- Bulk Upload
- HubSpot Integration

### P1 (Important)
- [ ] Configure SMTP for email sending
- [ ] Scheduled weekly emails
- [ ] Two-way HubSpot sync (push data to HubSpot)

### P2 (Nice to Have)
- [ ] Export reports to PDF/Excel
- [ ] Team member assignment
- [ ] Dark mode

## Technical Notes
- HubSpot integration requires Private App Access Token with scopes: crm.objects.contacts.read, crm.objects.companies.read, crm.objects.deals.read, crm.schemas.deals.read, crm.objects.tasks.read
- Excel processing uses openpyxl library
- Bulk upload matches existing clients by POC email
