import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { FolderKanban, Mail, Lock, Shield, ArrowLeft } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const { login, verifyMfa, resendMfaCode, cancelMfa, mfaPending } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      const result = await login(email, password);
      if (result.requires_mfa) {
        toast.info(result.message);
      } else {
        toast.success('Welcome back!');
        navigate('/dashboard');
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleMfaVerify = async (e) => {
    e.preventDefault();
    if (!mfaCode || mfaCode.length !== 6) {
      toast.error('Please enter a 6-digit code');
      return;
    }

    setLoading(true);
    try {
      await verifyMfa(mfaCode);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Invalid verification code');
      setMfaCode('');
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    setResending(true);
    try {
      await resendMfaCode();
      toast.success('New code sent to your email');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to resend code');
    } finally {
      setResending(false);
    }
  };

  const handleCancelMfa = () => {
    cancelMfa();
    setMfaCode('');
  };

  // MFA Verification Screen
  if (mfaPending) {
    return (
      <div className="min-h-screen flex" data-testid="mfa-verification-page">
        <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-slate-50">
          <Card className="w-full max-w-md border-0 shadow-xl">
            <CardHeader className="text-center pb-2">
              <div className="mx-auto w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center mb-4">
                <Shield className="w-7 h-7 text-emerald-400" />
              </div>
              <CardTitle className="text-2xl font-['Chivo']">Two-Factor Authentication</CardTitle>
              <CardDescription>
                {mfaPending.mfa_method === 'email' 
                  ? 'Enter the 6-digit code sent to your email'
                  : 'Enter the 6-digit code from your authenticator app'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleMfaVerify} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="mfa_code">Verification Code</Label>
                  <Input
                    id="mfa_code"
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="000000"
                    value={mfaCode}
                    onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
                    className="text-center text-2xl tracking-widest"
                    data-testid="mfa-code-input"
                    autoFocus
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-slate-900 hover:bg-slate-800"
                  disabled={loading || mfaCode.length !== 6}
                  data-testid="mfa-verify-btn"
                >
                  {loading ? 'Verifying...' : 'Verify'}
                </Button>
              </form>
              
              <div className="mt-6 space-y-3">
                {mfaPending.mfa_method === 'email' && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleResendCode}
                    disabled={resending}
                    data-testid="resend-code-btn"
                  >
                    {resending ? 'Sending...' : 'Resend Code'}
                  </Button>
                )}
                <Button
                  variant="ghost"
                  className="w-full"
                  onClick={handleCancelMfa}
                  data-testid="cancel-mfa-btn"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Login
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div 
          className="hidden lg:block lg:w-1/2 bg-cover bg-center relative"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1589936009537-bda4341d578f?crop=entropy&cs=srgb&fm=jpg&q=85)' }}
        >
          <div className="absolute inset-0 bg-slate-900/60" />
          <div className="absolute inset-0 flex items-center justify-center p-12">
            <div className="text-white text-center max-w-lg">
              <h2 className="text-4xl font-bold font-['Chivo'] mb-4">
                Secure Access
              </h2>
              <p className="text-lg text-slate-200">
                Two-factor authentication adds an extra layer of security to protect your account.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Normal Login Screen
  return (
    <div className="min-h-screen flex" data-testid="login-page">
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-slate-50">
        <Card className="w-full max-w-md border-0 shadow-xl">
          <CardHeader className="text-center pb-2">
            <div className="mx-auto w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center mb-4">
              <FolderKanban className="w-7 h-7 text-emerald-400" />
            </div>
            <CardTitle className="text-2xl font-['Chivo']">Welcome back</CardTitle>
            <CardDescription>Sign in to your account to continue</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    data-testid="login-email-input"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10"
                    data-testid="login-password-input"
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full bg-slate-900 hover:bg-slate-800"
                disabled={loading}
                data-testid="login-submit-btn"
              >
                {loading ? 'Signing in...' : 'Sign in'}
              </Button>
            </form>
            <p className="mt-6 text-center text-sm text-slate-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-emerald-600 hover:underline font-medium" data-testid="register-link">
                Create one
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>

      <div 
        className="hidden lg:block lg:w-1/2 bg-cover bg-center relative"
        style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1589936009537-bda4341d578f?crop=entropy&cs=srgb&fm=jpg&q=85)' }}
      >
        <div className="absolute inset-0 bg-slate-900/60" />
        <div className="absolute inset-0 flex items-center justify-center p-12">
          <div className="text-white text-center max-w-lg">
            <h2 className="text-4xl font-bold font-['Chivo'] mb-4">
              Client Project Management
            </h2>
            <p className="text-lg text-slate-200">
              Track deadlines, manage engagements, and stay on top of your client work with our comprehensive project management system.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
