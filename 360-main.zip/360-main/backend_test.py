#!/usr/bin/env python3

import requests
import sys
import json
from datetime import datetime, timedelta
from typing import Dict, Any

class ProjectManagementAPITester:
    def __init__(self, base_url="https://projectdeadline.preview.emergentagent.com"):
        self.base_url = base_url
        self.token = None
        self.user_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.created_resources = {
            'clients': [],
            'projects': []
        }

    def run_test(self, name: str, method: str, endpoint: str, expected_status: int, 
                 data: Dict[Any, Any] = None, headers: Dict[str, str] = None) -> tuple:
        """Run a single API test"""
        url = f"{self.base_url}/api/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            
            if success:
                self.tests_passed += 1
                print(f"✅ PASSED - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ FAILED - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Response: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ FAILED - Error: {str(e)}")
            return False, {}

    def test_auth_register(self):
        """Test user registration"""
        timestamp = datetime.now().strftime('%H%M%S')
        user_data = {
            "name": f"Test User {timestamp}",
            "email": f"test{timestamp}@example.com",
            "password": "testpass123"
        }
        
        success, response = self.run_test(
            "User Registration",
            "POST",
            "auth/register",
            200,
            data=user_data
        )
        
        if success and 'access_token' in response:
            self.token = response['access_token']
            self.user_id = response['user']['id']
            print(f"   Token obtained: {self.token[:20]}...")
            return True
        return False

    def test_auth_login(self):
        """Test user login with existing credentials"""
        # Try to login with the registered user
        if not hasattr(self, '_test_email'):
            return True  # Skip if no test user created
            
        login_data = {
            "email": self._test_email,
            "password": "testpass123"
        }
        
        success, response = self.run_test(
            "User Login",
            "POST", 
            "auth/login",
            200,
            data=login_data
        )
        
        if success and 'access_token' in response:
            self.token = response['access_token']
            return True
        return False

    def test_auth_me(self):
        """Test get current user"""
        success, response = self.run_test(
            "Get Current User",
            "GET",
            "auth/me",
            200
        )
        return success

    def test_create_client(self):
        """Test client creation"""
        client_data = {
            "company_name": "Test Company Inc",
            "poc_name": "John Doe",
            "poc_email": "john@testcompany.com",
            "notes": "Test client for API testing",
            "tier": "Tier 2"
        }
        
        success, response = self.run_test(
            "Create Client",
            "POST",
            "clients",
            200,
            data=client_data
        )
        
        if success and 'id' in response:
            self.created_resources['clients'].append(response['id'])
            return response['id']
        return None

    def test_get_clients(self):
        """Test get all clients"""
        success, response = self.run_test(
            "Get All Clients",
            "GET",
            "clients",
            200
        )
        return success

    def test_get_client_by_id(self, client_id):
        """Test get client by ID"""
        success, response = self.run_test(
            "Get Client by ID",
            "GET",
            f"clients/{client_id}",
            200
        )
        return success

    def test_create_project(self, client_id):
        """Test project creation"""
        due_date = (datetime.now() + timedelta(days=30)).isoformat()
        project_data = {
            "client_id": client_id,
            "name": "Test Project Q4 2025",
            "description": "Test project for API testing",
            "status": "Planning Calls Scheduled",
            "priority": "High",
            "due_date": due_date,
            "notes": "Test project notes"
        }
        
        success, response = self.run_test(
            "Create Project",
            "POST",
            "projects",
            200,
            data=project_data
        )
        
        if success and 'id' in response:
            self.created_resources['projects'].append(response['id'])
            return response['id']
        return None

    def test_get_projects(self):
        """Test get all projects"""
        success, response = self.run_test(
            "Get All Projects",
            "GET",
            "projects",
            200
        )
        return success

    def test_get_project_by_id(self, project_id):
        """Test get project by ID"""
        success, response = self.run_test(
            "Get Project by ID",
            "GET",
            f"projects/{project_id}",
            200
        )
        return success

    def test_update_project(self, project_id):
        """Test project update"""
        update_data = {
            "status": "Kickoff Calls Scheduled",
            "priority": "Critical",
            "notes": "Updated project notes"
        }
        
        success, response = self.run_test(
            "Update Project",
            "PUT",
            f"projects/{project_id}",
            200,
            data=update_data
        )
        return success

    def test_dashboard_stats(self):
        """Test dashboard statistics"""
        success, response = self.run_test(
            "Dashboard Statistics",
            "GET",
            "dashboard/stats",
            200
        )
        
        if success:
            expected_fields = ['total_clients', 'total_projects', 'projects_by_status', 
                             'projects_by_priority', 'overdue_projects', 'due_this_week']
            for field in expected_fields:
                if field not in response:
                    print(f"   Warning: Missing field '{field}' in dashboard stats")
        
        return success

    def test_dashboard_upcoming(self):
        """Test upcoming deadlines"""
        success, response = self.run_test(
            "Upcoming Deadlines",
            "GET",
            "dashboard/upcoming?days=7",
            200
        )
        return success

    def test_dashboard_overdue(self):
        """Test overdue projects"""
        success, response = self.run_test(
            "Overdue Projects",
            "GET",
            "dashboard/overdue",
            200
        )
        return success

    def test_email_settings(self):
        """Test email settings"""
        success, response = self.run_test(
            "Get Email Settings",
            "GET",
            "email/settings",
            200
        )
        return success

    def test_update_email_settings(self):
        """Test update email settings"""
        settings_data = {
            "enabled": True,
            "frequency": "weekly",
            "day_of_week": "Monday",
            "time_of_day": "09:00",
            "recipients": ["test@example.com"]
        }
        
        success, response = self.run_test(
            "Update Email Settings",
            "PUT",
            "email/settings",
            200,
            data=settings_data
        )
        return success

    def test_config_endpoints(self):
        """Test configuration endpoints"""
        endpoints = [
            ("Get Statuses", "config/statuses"),
            ("Get Priorities", "config/priorities"),
            ("Get Tiers", "config/tiers")
        ]
        
        all_passed = True
        for name, endpoint in endpoints:
            success, response = self.run_test(name, "GET", endpoint, 200)
            if not success:
                all_passed = False
            
            # Special check for tiers - should only have 3 tiers now
            if endpoint == "config/tiers" and success:
                tiers = response.get('tiers', [])
                if len(tiers) != 3:
                    print(f"   ❌ Expected 3 tiers, got {len(tiers)}: {tiers}")
                    all_passed = False
                elif "Tier 4" in tiers:
                    print(f"   ❌ Tier 4 should be removed, got: {tiers}")
                    all_passed = False
                else:
                    print(f"   ✅ Tiers correctly reduced to 3: {tiers}")
        
        return all_passed

    def test_mfa_status(self):
        """Test MFA status endpoint"""
        success, response = self.run_test(
            "Get MFA Status",
            "GET",
            "mfa/status",
            200
        )
        
        if success:
            expected_fields = ['mfa_enabled', 'mfa_method']
            for field in expected_fields:
                if field not in response:
                    print(f"   Warning: Missing field '{field}' in MFA status")
                    return False
            print(f"   MFA Status: enabled={response.get('mfa_enabled')}, method={response.get('mfa_method')}")
        
        return success

    def test_mfa_setup_totp(self):
        """Test TOTP MFA setup"""
        setup_data = {"method": "totp"}
        
        success, response = self.run_test(
            "Setup TOTP MFA",
            "POST",
            "mfa/setup",
            200,
            data=setup_data
        )
        
        if success:
            expected_fields = ['method', 'secret', 'qr_code', 'message']
            for field in expected_fields:
                if field not in response:
                    print(f"   Warning: Missing field '{field}' in TOTP setup")
                    return False
            
            if response['method'] != 'totp':
                print(f"   Error: Expected method 'totp', got '{response['method']}'")
                return False
            
            if not response.get('secret') or not response.get('qr_code'):
                print(f"   Error: Missing secret or QR code in TOTP setup")
                return False
            
            print(f"   ✅ TOTP setup successful with secret and QR code")
            return response  # Return response for potential use in enable test
        
        return False

    def test_mfa_setup_email(self):
        """Test Email MFA setup"""
        setup_data = {"method": "email"}
        
        success, response = self.run_test(
            "Setup Email MFA",
            "POST",
            "mfa/setup",
            200,
            data=setup_data
        )
        
        if success:
            expected_fields = ['method', 'message']
            for field in expected_fields:
                if field not in response:
                    print(f"   Warning: Missing field '{field}' in Email setup")
                    return False
            
            if response['method'] != 'email':
                print(f"   Error: Expected method 'email', got '{response['method']}'")
                return False
            
            print(f"   ✅ Email MFA setup successful")
        
        return success

    def test_mfa_disable(self):
        """Test MFA disable"""
        success, response = self.run_test(
            "Disable MFA",
            "POST",
            "mfa/disable",
            200
        )
        
        if success and 'message' in response:
            print(f"   ✅ MFA disabled: {response['message']}")
        
        return success

    def test_client_tier_validation(self):
        """Test that client creation validates tier correctly (only Tier 1-3)"""
        # Test valid tier
        valid_client_data = {
            "company_name": "Valid Tier Company",
            "poc_name": "Jane Doe",
            "poc_email": "jane@validtier.com",
            "notes": "Test client with valid tier",
            "tier": "Tier 3"
        }
        
        success, response = self.run_test(
            "Create Client with Valid Tier (Tier 3)",
            "POST",
            "clients",
            200,
            data=valid_client_data
        )
        
        if success and 'id' in response:
            self.created_resources['clients'].append(response['id'])
            print(f"   ✅ Client created with Tier 3")
        
        # Test invalid tier (Tier 4 should be rejected)
        invalid_client_data = {
            "company_name": "Invalid Tier Company",
            "poc_name": "Bob Smith",
            "poc_email": "bob@invalidtier.com",
            "notes": "Test client with invalid tier",
            "tier": "Tier 4"
        }
        
        invalid_success, invalid_response = self.run_test(
            "Create Client with Invalid Tier (Tier 4)",
            "POST",
            "clients",
            400,  # Should return 400 for invalid tier
            data=invalid_client_data
        )
        
        if invalid_success:
            print(f"   ✅ Tier 4 correctly rejected")
        else:
            print(f"   ❌ Tier 4 validation failed - should return 400")
            return False
        
        return success

    def test_bulk_template_download(self):
        """Test bulk upload template download"""
        success, response = self.run_test(
            "Download Bulk Template",
            "GET",
            "bulk/template",
            200
        )
        
        if success:
            print(f"   ✅ Template download endpoint working")
        
        return success

    def test_bulk_upload_validation(self):
        """Test bulk upload endpoint validation (without actual file)"""
        # Test without file - should return 422 (validation error)
        success, response = self.run_test(
            "Bulk Upload Validation (No File)",
            "POST",
            "bulk/upload",
            422  # FastAPI validation error for missing file
        )
        
        if success:
            print(f"   ✅ Bulk upload correctly validates missing file")
        
        return success

    def test_hubspot_status(self):
        """Test HubSpot configuration status"""
        success, response = self.run_test(
            "HubSpot Status",
            "GET",
            "hubspot/status",
            200
        )
        
        if success:
            expected_fields = ['configured']
            for field in expected_fields:
                if field not in response:
                    print(f"   Warning: Missing field '{field}' in HubSpot status")
                    return False
            
            configured = response.get('configured', False)
            print(f"   HubSpot configured: {configured}")
            
            if configured:
                print(f"   Updated at: {response.get('updated_at', 'N/A')}")
        
        return success

    def test_hubspot_configure(self):
        """Test HubSpot API key configuration"""
        config_data = {
            "api_key": "test-api-key-12345"
        }
        
        success, response = self.run_test(
            "Configure HubSpot API Key",
            "POST",
            "hubspot/configure",
            200,
            data=config_data
        )
        
        if success and 'message' in response:
            print(f"   ✅ HubSpot configuration: {response['message']}")
        
        return success

    def test_hubspot_endpoints_without_key(self):
        """Test HubSpot endpoints without valid API key (should fail gracefully)"""
        endpoints = [
            ("HubSpot Contacts", "hubspot/contacts", [401]),
            ("HubSpot Companies", "hubspot/companies", [401]),
            ("HubSpot Deals", "hubspot/deals", [401]),
            ("HubSpot Pipelines", "hubspot/pipelines", [401]),
            ("HubSpot Pipeline Summary", "hubspot/pipeline-summary", [401]),
            ("HubSpot Activities", "hubspot/activities", [200, 401])  # Activities might return empty data gracefully
        ]
        
        all_handled = True
        for name, endpoint, expected_codes in endpoints:
            # Try the endpoint and check if it returns one of the expected codes
            url = f"{self.base_url}/api/{endpoint}"
            test_headers = {'Content-Type': 'application/json'}
            if self.token:
                test_headers['Authorization'] = f'Bearer {self.token}'
            
            try:
                response = requests.get(url, headers=test_headers, timeout=30)
                if response.status_code in expected_codes:
                    print(f"   ✅ {name} correctly handles invalid API key (status: {response.status_code})")
                else:
                    print(f"   ❌ {name} returned unexpected status {response.status_code}, expected one of {expected_codes}")
                    all_handled = False
            except Exception as e:
                print(f"   ❌ {name} failed with error: {str(e)}")
                all_handled = False
        
        return all_handled

    def cleanup_resources(self):
        """Clean up created test resources"""
        print(f"\n🧹 Cleaning up test resources...")
        
        # Delete projects first (due to foreign key constraints)
        for project_id in self.created_resources['projects']:
            try:
                self.run_test(
                    f"Delete Project {project_id}",
                    "DELETE",
                    f"projects/{project_id}",
                    200
                )
            except:
                pass
        
        # Delete clients
        for client_id in self.created_resources['clients']:
            try:
                self.run_test(
                    f"Delete Client {client_id}",
                    "DELETE",
                    f"clients/{client_id}",
                    200
                )
            except:
                pass

    def run_all_tests(self):
        """Run all API tests"""
        print("🚀 Starting Project Management API Tests")
        print(f"Base URL: {self.base_url}")
        
        try:
            # Authentication tests
            if not self.test_auth_register():
                print("❌ Registration failed, stopping tests")
                return False
            
            if not self.test_auth_me():
                print("❌ Auth verification failed")
                return False
            
            # Client tests
            client_id = self.test_create_client()
            if not client_id:
                print("❌ Client creation failed, stopping tests")
                return False
            
            if not self.test_get_clients():
                print("❌ Get clients failed")
                return False
            
            if not self.test_get_client_by_id(client_id):
                print("❌ Get client by ID failed")
                return False
            
            # Project tests
            project_id = self.test_create_project(client_id)
            if not project_id:
                print("❌ Project creation failed")
                return False
            
            if not self.test_get_projects():
                print("❌ Get projects failed")
                return False
            
            if not self.test_get_project_by_id(project_id):
                print("❌ Get project by ID failed")
                return False
            
            if not self.test_update_project(project_id):
                print("❌ Update project failed")
                return False
            
            # Dashboard tests
            if not self.test_dashboard_stats():
                print("❌ Dashboard stats failed")
                return False
            
            if not self.test_dashboard_upcoming():
                print("❌ Dashboard upcoming failed")
                return False
            
            if not self.test_dashboard_overdue():
                print("❌ Dashboard overdue failed")
                return False
            
            # Email tests
            if not self.test_email_settings():
                print("❌ Email settings failed")
                return False
            
            if not self.test_update_email_settings():
                print("❌ Update email settings failed")
                return False
            
            # Config tests
            if not self.test_config_endpoints():
                print("❌ Config endpoints failed")
                return False
            
            # MFA tests
            if not self.test_mfa_status():
                print("❌ MFA status failed")
                return False
            
            if not self.test_mfa_setup_totp():
                print("❌ MFA TOTP setup failed")
                return False
            
            if not self.test_mfa_setup_email():
                print("❌ MFA Email setup failed")
                return False
            
            if not self.test_mfa_disable():
                print("❌ MFA disable failed")
                return False
            
            # Client tier validation tests
            if not self.test_client_tier_validation():
                print("❌ Client tier validation failed")
                return False
            
            # Bulk Upload tests
            if not self.test_bulk_template_download():
                print("❌ Bulk template download failed")
                return False
            
            if not self.test_bulk_upload_validation():
                print("❌ Bulk upload validation failed")
                return False
            
            # HubSpot tests
            if not self.test_hubspot_status():
                print("❌ HubSpot status failed")
                return False
            
            if not self.test_hubspot_configure():
                print("❌ HubSpot configure failed")
                return False
            
            if not self.test_hubspot_endpoints_without_key():
                print("❌ HubSpot endpoints validation failed")
                return False
            
            return True
            
        finally:
            # Always cleanup
            self.cleanup_resources()

def main():
    tester = ProjectManagementAPITester()
    
    success = tester.run_all_tests()
    
    # Print final results
    print(f"\n📊 Test Results:")
    print(f"   Tests run: {tester.tests_run}")
    print(f"   Tests passed: {tester.tests_passed}")
    print(f"   Success rate: {(tester.tests_passed/tester.tests_run*100):.1f}%")
    
    if success and tester.tests_passed == tester.tests_run:
        print("🎉 All tests passed!")
        return 0
    else:
        print("❌ Some tests failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())