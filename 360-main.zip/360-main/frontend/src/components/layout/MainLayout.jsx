import { Sidebar } from './Sidebar';
import { cn } from '@/lib/utils';

export const MainLayout = ({ children, title, actions }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      
      {/* Main content */}
      <main className="ml-64 min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-sm border-b border-slate-200">
          <div className="h-16 px-8 flex items-center justify-between">
            <h1 className="text-xl font-bold font-['Chivo'] text-slate-900">
              {title}
            </h1>
            {actions && (
              <div className="flex items-center gap-3">
                {actions}
              </div>
            )}
          </div>
        </header>

        {/* Content */}
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};
