import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { emailApi } from '@/lib/api';
import { formatDateTime } from '@/lib/utils';
import { Mail, Send, Clock, CheckCircle, XCircle, Plus, X } from 'lucide-react';
import { toast } from 'sonner';

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const EmailLogRow = ({ log, index }) => {
  return (
    <tr className="border-b" data-testid={`email-log-${index}`}>
      <td className="p-3 text-sm">{log.recipient}</td>
      <td className="p-3">
        {log.status === 'sent' ? (
          <Badge className="bg-emerald-100 text-emerald-700 flex items-center gap-1 w-fit">
            <CheckCircle className="w-3 h-3" />
            Sent
          </Badge>
        ) : (
          <Badge variant="destructive" className="flex items-center gap-1 w-fit">
            <XCircle className="w-3 h-3" />
            Failed
          </Badge>
        )}
      </td>
      <td className="p-3 text-sm text-slate-500">
        {formatDateTime(log.sent_at)}
      </td>
    </tr>
  );
};

const RecipientBadge = ({ email, onRemove }) => {
  return (
    <Badge 
      variant="secondary" 
      className="pl-3 pr-1 py-1 flex items-center gap-1"
      data-testid={`recipient-badge`}
    >
      {email}
      <button 
        onClick={() => onRemove(email)}
        className="ml-1 hover:bg-slate-300 rounded p-0.5"
      >
        <X className="w-3 h-3" />
      </button>
    </Badge>
  );
};

export default function EmailSettingsPage() {
  const [settings, setSettings] = useState({
    enabled: false,
    frequency: 'weekly',
    day_of_week: 'Monday',
    time_of_day: '09:00',
    recipients: []
  });
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);
  const [newRecipient, setNewRecipient] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const settingsRes = await emailApi.getSettings();
      const logsRes = await emailApi.getLogs();
      setSettings(settingsRes.data);
      setLogs(logsRes.data || []);
    } catch (error) {
      toast.error('Failed to load email settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await emailApi.updateSettings(settings);
      toast.success('Email settings saved');
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSendTest = async () => {
    if (!settings.recipients || settings.recipients.length === 0) {
      toast.error('Please add at least one recipient');
      return;
    }
    setSending(true);
    try {
      await emailApi.sendTest(settings.recipients[0]);
      toast.success('Test email sent');
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to send test email');
    } finally {
      setSending(false);
    }
  };

  const handleSendWeekly = async () => {
    if (!settings.recipients || settings.recipients.length === 0) {
      toast.error('Please add at least one recipient');
      return;
    }
    setSending(true);
    try {
      await emailApi.sendWeekly();
      toast.success('Weekly email sent');
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to send weekly email');
    } finally {
      setSending(false);
    }
  };

  const addRecipient = () => {
    if (!newRecipient) return;
    if (!newRecipient.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    const currentRecipients = settings.recipients || [];
    if (currentRecipients.includes(newRecipient)) {
      toast.error('Recipient already added');
      return;
    }
    setSettings({
      ...settings,
      recipients: [...currentRecipients, newRecipient]
    });
    setNewRecipient('');
  };

  const removeRecipient = (email) => {
    const filtered = (settings.recipients || []).filter(r => r !== email);
    setSettings({
      ...settings,
      recipients: filtered
    });
  };

  const updateSetting = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return (
      <MainLayout title="Email Settings">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        </div>
      </MainLayout>
    );
  }

  const recipientsList = settings.recipients || [];
  const hasRecipients = recipientsList.length > 0;

  return (
    <MainLayout title="Email Settings">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-testid="email-settings-page">
        <Card className="border border-slate-200 shadow-sm" data-testid="email-settings-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Weekly Email Configuration
            </CardTitle>
            <CardDescription>
              Configure automated email reminders for upcoming deadlines
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="enabled" className="text-sm font-medium">Enable Email Reminders</Label>
                <p className="text-xs text-slate-500 mt-0.5">Automatically send reminder emails</p>
              </div>
              <Switch
                id="enabled"
                checked={settings.enabled}
                onCheckedChange={(checked) => updateSetting('enabled', checked)}
                data-testid="email-enabled-switch"
              />
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency</Label>
                <Select 
                  value={settings.frequency} 
                  onValueChange={(value) => updateSetting('frequency', value)}
                >
                  <SelectTrigger id="frequency" data-testid="frequency-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {settings.frequency === 'weekly' && (
                <div className="space-y-2">
                  <Label htmlFor="day_of_week">Day of Week</Label>
                  <Select 
                    value={settings.day_of_week} 
                    onValueChange={(value) => updateSetting('day_of_week', value)}
                  >
                    <SelectTrigger id="day_of_week" data-testid="day-of-week-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DAYS_OF_WEEK.map((day) => (
                        <SelectItem key={day} value={day}>{day}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="time_of_day">Time</Label>
                <Input
                  id="time_of_day"
                  type="time"
                  value={settings.time_of_day}
                  onChange={(e) => updateSetting('time_of_day', e.target.value)}
                  data-testid="time-input"
                />
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-100">
              <Label>Email Recipients</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="email@example.com"
                  value={newRecipient}
                  onChange={(e) => setNewRecipient(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addRecipient()}
                  data-testid="recipient-input"
                />
                <Button type="button" onClick={addRecipient} variant="outline" data-testid="add-recipient-btn">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {hasRecipients && (
                <div className="flex flex-wrap gap-2">
                  {recipientsList.map((email, idx) => (
                    <RecipientBadge 
                      key={`recipient-${idx}`} 
                      email={email} 
                      onRemove={removeRecipient} 
                    />
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-4 border-t border-slate-100">
              <Button onClick={handleSave} disabled={saving} data-testid="save-settings-btn">
                {saving ? 'Saving...' : 'Save Settings'}
              </Button>
              <Button 
                variant="outline" 
                onClick={handleSendTest} 
                disabled={sending || !hasRecipients}
                data-testid="send-test-btn"
              >
                <Send className="w-4 h-4 mr-2" />
                Send Test
              </Button>
              <Button 
                variant="outline" 
                onClick={handleSendWeekly} 
                disabled={sending || !hasRecipients}
                data-testid="send-weekly-btn"
              >
                <Mail className="w-4 h-4 mr-2" />
                Send Now
              </Button>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mt-4">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> To send emails, configure SMTP settings in backend environment (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM_EMAIL).
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-slate-200 shadow-sm" data-testid="email-logs-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Email History
            </CardTitle>
            <CardDescription>
              Recent email delivery logs
            </CardDescription>
          </CardHeader>
          <CardContent>
            {logs.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-8">
                No emails sent yet
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-slate-50/50 border-b">
                      <th className="p-3 text-left font-semibold text-xs uppercase">Recipient</th>
                      <th className="p-3 text-left font-semibold text-xs uppercase">Status</th>
                      <th className="p-3 text-left font-semibold text-xs uppercase">Sent At</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((log, index) => (
                      <EmailLogRow key={`log-${index}`} log={log} index={index} />
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
