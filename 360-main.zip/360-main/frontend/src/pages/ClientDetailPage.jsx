import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { clientsApi, projectsApi } from '@/lib/api';
import { 
  cn, 
  getStatusClass, 
  getPriorityClass, 
  getTierClass, 
  formatDate, 
  isOverdue,
  PROJECT_STATUSES,
  PRIORITY_LEVELS 
} from '@/lib/utils';
import { 
  ArrowLeft, 
  Plus, 
  Building2, 
  User, 
  Mail, 
  FileText, 
  Edit,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner';

export default function ClientDetailPage() {
  const { clientId } = useParams();
  const navigate = useNavigate();
  const [client, setClient] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);

  // Project form state
  const [projectForm, setProjectForm] = useState({
    name: '',
    description: '',
    status: 'Planning Calls Scheduled',
    priority: 'Medium',
    due_date: '',
    notes: ''
  });

  useEffect(() => {
    fetchData();
  }, [clientId]);

  const fetchData = async () => {
    try {
      const [clientRes, projectsRes] = await Promise.all([
        clientsApi.getById(clientId),
        projectsApi.getAll({ client_id: clientId })
      ]);
      setClient(clientRes.data);
      setProjects(projectsRes.data);
    } catch (error) {
      toast.error('Failed to load client details');
      navigate('/clients');
    } finally {
      setLoading(false);
    }
  };

  const handleProjectSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingProject) {
        await projectsApi.update(editingProject.id, projectForm);
        toast.success('Project updated successfully');
      } else {
        await projectsApi.create({
          ...projectForm,
          client_id: clientId
        });
        toast.success('Project created successfully');
      }
      setIsProjectDialogOpen(false);
      resetProjectForm();
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save project');
    }
  };

  const handleEditProject = (project) => {
    setEditingProject(project);
    setProjectForm({
      name: project.name,
      description: project.description || '',
      status: project.status,
      priority: project.priority,
      due_date: project.due_date.split('T')[0],
      notes: project.notes || ''
    });
    setIsProjectDialogOpen(true);
  };

  const handleDeleteProject = async (projectId) => {
    if (!window.confirm('Are you sure you want to delete this project?')) {
      return;
    }
    try {
      await projectsApi.delete(projectId);
      toast.success('Project deleted successfully');
      fetchData();
    } catch (error) {
      toast.error('Failed to delete project');
    }
  };

  const resetProjectForm = () => {
    setEditingProject(null);
    setProjectForm({
      name: '',
      description: '',
      status: 'Planning Calls Scheduled',
      priority: 'Medium',
      due_date: '',
      notes: ''
    });
  };

  if (loading) {
    return (
      <MainLayout title="Client Details">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        </div>
      </MainLayout>
    );
  }

  if (!client) {
    return (
      <MainLayout title="Client Not Found">
        <div className="text-center py-12">
          <p className="text-slate-500 mb-4">Client not found</p>
          <Link to="/clients">
            <Button>Back to Clients</Button>
          </Link>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title={client.company_name}
      actions={
        <div className="flex items-center gap-3">
          <Link to="/clients">
            <Button variant="outline" data-testid="back-to-clients-btn">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <Dialog open={isProjectDialogOpen} onOpenChange={(open) => {
            setIsProjectDialogOpen(open);
            if (!open) resetProjectForm();
          }}>
            <DialogTrigger asChild>
              <Button data-testid="add-project-btn">
                <Plus className="w-4 h-4 mr-2" />
                Add Project
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingProject ? 'Edit Project' : 'Add New Project'}</DialogTitle>
                <DialogDescription>
                  {editingProject ? 'Update project details' : 'Create a new project for this client'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleProjectSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="project_name">Project Name</Label>
                  <Input
                    id="project_name"
                    value={projectForm.name}
                    onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })}
                    placeholder="Q4 2025 Audit"
                    required
                    data-testid="project-name-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={projectForm.description}
                    onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
                    placeholder="Project description..."
                    rows={2}
                    data-testid="project-description-input"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select 
                      value={projectForm.status} 
                      onValueChange={(value) => setProjectForm({ ...projectForm, status: value })}
                    >
                      <SelectTrigger data-testid="project-status-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="max-h-60">
                        {PROJECT_STATUSES.map((status) => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select 
                      value={projectForm.priority} 
                      onValueChange={(value) => setProjectForm({ ...projectForm, priority: value })}
                    >
                      <SelectTrigger data-testid="project-priority-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PRIORITY_LEVELS.map((priority) => (
                          <SelectItem key={priority} value={priority}>{priority}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="due_date">Due Date</Label>
                  <Input
                    id="due_date"
                    type="date"
                    value={projectForm.due_date}
                    onChange={(e) => setProjectForm({ ...projectForm, due_date: e.target.value })}
                    required
                    data-testid="project-due-date-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={projectForm.notes}
                    onChange={(e) => setProjectForm({ ...projectForm, notes: e.target.value })}
                    placeholder="Additional notes..."
                    rows={2}
                    data-testid="project-notes-input"
                  />
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsProjectDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" data-testid="project-submit-btn">
                    {editingProject ? 'Update Project' : 'Add Project'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      }
    >
      <div className="space-y-6" data-testid="client-detail-page">
        {/* Client Info Card */}
        <Card className="border border-slate-200 shadow-sm" data-testid="client-info-card">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wide">Company</p>
                  <p className="font-semibold text-slate-900">{client.company_name}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                  <User className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wide">POC Name</p>
                  <p className="font-semibold text-slate-900">{client.poc_name}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                  <Mail className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wide">POC Email</p>
                  <a href={`mailto:${client.poc_email}`} className="font-semibold text-emerald-600 hover:underline">
                    {client.poc_email}
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Badge className={cn("text-sm", getTierClass(client.tier))}>
                  {client.tier}
                </Badge>
              </div>
            </div>
            {client.notes && (
              <div className="mt-6 pt-6 border-t border-slate-100">
                <div className="flex items-start gap-3">
                  <FileText className="w-4 h-4 text-slate-400 mt-0.5" />
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Notes</p>
                    <p className="text-sm text-slate-600">{client.notes}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Projects Table */}
        <Card className="border border-slate-200 shadow-sm" data-testid="client-projects-table">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold">
              Projects ({projects.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {projects.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500 mb-4">No projects yet</p>
                <Button onClick={() => setIsProjectDialogOpen(true)} data-testid="empty-add-project-btn">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Project
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/50">
                      <TableHead className="font-semibold">Project Name</TableHead>
                      <TableHead className="font-semibold">Status</TableHead>
                      <TableHead className="font-semibold">Priority</TableHead>
                      <TableHead className="font-semibold">Due Date</TableHead>
                      <TableHead className="font-semibold text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((project) => (
                      <TableRow 
                        key={project.id} 
                        className="hover:bg-slate-50"
                        data-testid={`project-row-${project.id}`}
                      >
                        <TableCell>
                          <div>
                            <p className="font-medium text-slate-900">{project.name}</p>
                            {project.description && (
                              <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                                {project.description}
                              </p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={cn("text-xs", getStatusClass(project.status))}>
                            {project.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={cn("text-xs", getPriorityClass(project.priority))}>
                            {project.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {isOverdue(project.due_date) && project.status !== 'Completed' && project.status !== 'Issued' && (
                              <AlertTriangle className="w-4 h-4 text-rose-500" />
                            )}
                            <span className={cn(
                              "text-sm",
                              isOverdue(project.due_date) && project.status !== 'Completed' && project.status !== 'Issued'
                                ? "text-rose-600 font-medium"
                                : "text-slate-600"
                            )}>
                              {formatDate(project.due_date)}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleEditProject(project)}
                              data-testid={`edit-project-${project.id}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleDeleteProject(project.id)}
                              className="text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                              data-testid={`delete-project-${project.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
