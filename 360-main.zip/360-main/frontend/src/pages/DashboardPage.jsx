import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { dashboardApi, projectsApi } from '@/lib/api';
import { 
  cn, 
  getStatusClass, 
  getPriorityClass, 
  formatDate, 
  isOverdue, 
  getDaysUntilDue 
} from '@/lib/utils';
import { 
  Users, 
  FolderKanban, 
  AlertTriangle, 
  Clock, 
  TrendingUp,
  ArrowRight,
  CalendarDays
} from 'lucide-react';
import { toast } from 'sonner';

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [upcoming, setUpcoming] = useState([]);
  const [overdue, setOverdue] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, upcomingRes, overdueRes] = await Promise.all([
        dashboardApi.getStats(),
        dashboardApi.getUpcoming(7),
        dashboardApi.getOverdue()
      ]);
      setStats(statsRes.data);
      setUpcoming(upcomingRes.data);
      setOverdue(overdueRes.data);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <MainLayout title="Dashboard">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Dashboard"
      actions={
        <Link to="/projects">
          <Button data-testid="view-all-projects-btn">
            View All Projects
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </Link>
      }
    >
      <div className="space-y-8" data-testid="dashboard-content">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border border-slate-200 shadow-sm hover:shadow-md transition-shadow" data-testid="total-clients-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Total Clients</p>
                  <p className="text-3xl font-bold font-['Chivo'] text-slate-900 mt-1">
                    {stats?.total_clients || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-slate-200 shadow-sm hover:shadow-md transition-shadow" data-testid="total-projects-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Total Projects</p>
                  <p className="text-3xl font-bold font-['Chivo'] text-slate-900 mt-1">
                    {stats?.total_projects || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <FolderKanban className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-slate-200 shadow-sm hover:shadow-md transition-shadow" data-testid="overdue-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Overdue</p>
                  <p className={cn(
                    "text-3xl font-bold font-['Chivo'] mt-1",
                    stats?.overdue_projects > 0 ? "text-rose-600" : "text-slate-900"
                  )}>
                    {stats?.overdue_projects || 0}
                  </p>
                </div>
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center",
                  stats?.overdue_projects > 0 ? "bg-rose-100" : "bg-slate-100"
                )}>
                  <AlertTriangle className={cn(
                    "w-6 h-6",
                    stats?.overdue_projects > 0 ? "text-rose-600" : "text-slate-600"
                  )} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-slate-200 shadow-sm hover:shadow-md transition-shadow" data-testid="due-this-week-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Due This Week</p>
                  <p className="text-3xl font-bold font-['Chivo'] text-amber-600 mt-1">
                    {stats?.due_this_week || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Overdue Projects */}
          <Card className="lg:col-span-1 border border-slate-200 shadow-sm" data-testid="overdue-projects-list">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                  Overdue Projects
                </CardTitle>
                <Badge variant="destructive">{overdue.length}</Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {overdue.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-8">No overdue projects</p>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {overdue.slice(0, 5).map((project) => (
                    <Link 
                      key={project.id} 
                      to={`/clients/${project.client_id}`}
                      className="block p-3 bg-rose-50 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors"
                      data-testid={`overdue-project-${project.id}`}
                    >
                      <p className="font-medium text-sm text-slate-900 truncate">{project.name}</p>
                      <p className="text-xs text-slate-500 mt-1">{project.client_name}</p>
                      <div className="flex items-center justify-between mt-2">
                        <Badge variant="destructive" className="text-xs">
                          {Math.abs(getDaysUntilDue(project.due_date))} days overdue
                        </Badge>
                        <Badge className={cn("text-xs", getPriorityClass(project.priority))}>
                          {project.priority}
                        </Badge>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Deadlines */}
          <Card className="lg:col-span-2 border border-slate-200 shadow-sm" data-testid="upcoming-deadlines-list">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-amber-500" />
                  Upcoming Deadlines (7 Days)
                </CardTitle>
                <Link to="/calendar">
                  <Button variant="ghost" size="sm" data-testid="view-calendar-btn">
                    View Calendar
                    <ArrowRight className="ml-1 w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {upcoming.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-8">No upcoming deadlines</p>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {upcoming.map((project) => (
                    <Link 
                      key={project.id} 
                      to={`/clients/${project.client_id}`}
                      className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200 hover:bg-slate-100 transition-colors"
                      data-testid={`upcoming-project-${project.id}`}
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-slate-900 truncate">{project.name}</p>
                        <p className="text-xs text-slate-500">{project.client_name}</p>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <Badge className={cn("text-xs whitespace-nowrap", getStatusClass(project.status))}>
                          {project.status}
                        </Badge>
                        <span className="text-xs text-slate-500 whitespace-nowrap">
                          {formatDate(project.due_date)}
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Status Breakdown */}
        <Card className="border border-slate-200 shadow-sm" data-testid="status-breakdown">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-slate-500" />
              Projects by Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {stats?.projects_by_status && Object.entries(stats.projects_by_status).map(([status, count]) => (
                <div 
                  key={status}
                  className="p-3 rounded-lg border border-slate-200 bg-slate-50"
                  data-testid={`status-${status.replace(/\s+/g, '-').toLowerCase()}`}
                >
                  <Badge className={cn("text-xs mb-2", getStatusClass(status))}>
                    {count}
                  </Badge>
                  <p className="text-xs text-slate-600 line-clamp-2">{status}</p>
                </div>
              ))}
            </div>
            {(!stats?.projects_by_status || Object.keys(stats.projects_by_status).length === 0) && (
              <p className="text-sm text-slate-500 text-center py-4">No projects yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
