import { useState, useRef } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { bulkApi } from '@/lib/api';
import { 
  Download, 
  Upload, 
  FileSpreadsheet, 
  CheckCircle, 
  AlertCircle,
  Loader2,
  FileUp
} from 'lucide-react';
import { toast } from 'sonner';

const ResultCard = ({ result }) => {
  if (!result) return null;
  
  const hasErrors = result.errors && result.errors.length > 0;
  
  return (
    <Card className="border border-slate-200 shadow-sm" data-testid="upload-result-card">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-emerald-500" />
          Upload Results
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="bg-emerald-50 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-emerald-600">{result.clients_created}</p>
            <p className="text-sm text-slate-600">Clients Created</p>
          </div>
          <div className="bg-blue-50 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{result.clients_updated}</p>
            <p className="text-sm text-slate-600">Clients Updated</p>
          </div>
          <div className="bg-purple-50 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-purple-600">{result.projects_created}</p>
            <p className="text-sm text-slate-600">Projects Created</p>
          </div>
        </div>
        {hasErrors && (
          <ErrorList errors={result.errors} />
        )}
      </CardContent>
    </Card>
  );
};

const ErrorList = ({ errors }) => {
  return (
    <div className="mt-4">
      <div className="flex items-center gap-2 mb-2">
        <AlertCircle className="w-4 h-4 text-amber-500" />
        <span className="font-medium text-sm">Warnings ({errors.length})</span>
      </div>
      <div className="bg-amber-50 rounded-lg p-3 max-h-40 overflow-y-auto">
        {errors.map((error, index) => (
          <p key={`error-${index}`} className="text-sm text-amber-800 mb-1">
            {error}
          </p>
        ))}
      </div>
    </div>
  );
};

export default function BulkUploadPage() {
  const [uploading, setUploading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const handleDownloadTemplate = async () => {
    setDownloading(true);
    try {
      const response = await bulkApi.downloadTemplate();
      const blob = new Blob([response.data], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'client_project_template.xlsx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success('Template downloaded successfully');
    } catch (error) {
      toast.error('Failed to download template');
    } finally {
      setDownloading(false);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        toast.error('Please select an Excel file (.xlsx or .xls)');
        return;
      }
      setSelectedFile(file);
      setUploadResult(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    setUploading(true);
    try {
      const response = await bulkApi.upload(selectedFile);
      setUploadResult(response.data);
      toast.success('File processed successfully');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to process file');
    } finally {
      setUploading(false);
    }
  };

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const fileSize = selectedFile ? (selectedFile.size / 1024).toFixed(1) : 0;

  return (
    <MainLayout title="Bulk Upload">
      <div className="max-w-3xl space-y-6" data-testid="bulk-upload-page">
        <Card className="border border-slate-200 shadow-sm" data-testid="download-template-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5" />
              Step 1: Download Template
            </CardTitle>
            <CardDescription>
              Download the Excel template with pre-configured columns for clients and projects
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Button 
                onClick={handleDownloadTemplate}
                disabled={downloading}
                data-testid="download-template-btn"
              >
                {downloading ? (
                  <span className="flex items-center">
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Downloading...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Download className="w-4 h-4 mr-2" />
                    Download Template
                  </span>
                )}
              </Button>
              <span className="text-sm text-slate-500">
                Includes sheets for Clients and Projects with instructions
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-slate-200 shadow-sm" data-testid="upload-card">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Step 2: Upload Populated Template
            </CardTitle>
            <CardDescription>
              Fill in the template and upload it to create clients and projects in bulk
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div 
              className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center hover:border-emerald-400 transition-colors cursor-pointer"
              onClick={openFileDialog}
              data-testid="file-drop-zone"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileSelect}
                className="hidden"
                data-testid="file-input"
              />
              <FileUp className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              {selectedFile ? (
                <div>
                  <p className="font-medium text-slate-900">{selectedFile.name}</p>
                  <p className="text-sm text-slate-500 mt-1">{fileSize} KB</p>
                </div>
              ) : (
                <div>
                  <p className="font-medium text-slate-600">Click to select file</p>
                  <p className="text-sm text-slate-400 mt-1">or drag and drop</p>
                </div>
              )}
            </div>

            <Button 
              onClick={handleUpload}
              disabled={!selectedFile || uploading}
              className="w-full"
              data-testid="upload-btn"
            >
              {uploading ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </span>
              ) : (
                <span className="flex items-center justify-center">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload and Process
                </span>
              )}
            </Button>
          </CardContent>
        </Card>

        <ResultCard result={uploadResult} />

        <Card className="border border-slate-200 shadow-sm bg-slate-50" data-testid="instructions-card">
          <CardHeader>
            <CardTitle className="text-sm font-semibold">Template Instructions</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-slate-600 space-y-2">
            <p>1. Download the template and open it in Excel</p>
            <p>2. Fill in the <Badge variant="secondary">Clients</Badge> sheet with client information</p>
            <p>3. Fill in the <Badge variant="secondary">Projects</Badge> sheet - use exact client company names</p>
            <p>4. Delete the sample rows before uploading</p>
            <p>5. Save and upload the file</p>
            <p className="text-slate-500 italic mt-4">
              Note: Existing clients (matched by email) will be updated. New clients will be created.
            </p>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
