import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { projectsApi } from '@/lib/api';
import { 
  cn, 
  getStatusClass, 
  getPriorityClass, 
  formatDate, 
  isOverdue,
  PROJECT_STATUSES,
  PRIORITY_LEVELS 
} from '@/lib/utils';
import { Search, FolderKanban, AlertTriangle, Filter } from 'lucide-react';
import { toast } from 'sonner';

export default function ProjectsPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [overdueFilter, setOverdueFilter] = useState('all');

  useEffect(() => {
    fetchProjects();
  }, [statusFilter, priorityFilter, overdueFilter]);

  const fetchProjects = async () => {
    try {
      const params = {};
      if (statusFilter && statusFilter !== 'all') params.status = statusFilter;
      if (priorityFilter && priorityFilter !== 'all') params.priority = priorityFilter;
      if (overdueFilter === 'overdue') params.overdue = true;
      if (overdueFilter === 'not_overdue') params.overdue = false;
      
      const res = await projectsApi.getAll(params);
      setProjects(res.data);
    } catch (error) {
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const groupedByStatus = PROJECT_STATUSES.reduce((acc, status) => {
    acc[status] = projects.filter(p => p.status === status);
    return acc;
  }, {});

  return (
    <MainLayout title="Projects">
      <div className="space-y-6" data-testid="projects-page">
        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-64" data-testid="status-filter-select">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              <SelectItem value="all">All Statuses</SelectItem>
              {PROJECT_STATUSES.map((status) => (
                <SelectItem key={status} value={status}>{status}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-40" data-testid="priority-filter-select">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              {PRIORITY_LEVELS.map((priority) => (
                <SelectItem key={priority} value={priority}>{priority}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={overdueFilter} onValueChange={setOverdueFilter}>
            <SelectTrigger className="w-40" data-testid="overdue-filter-select">
              <SelectValue placeholder="Due Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="overdue">Overdue Only</SelectItem>
              <SelectItem value="not_overdue">Not Overdue</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Projects Table */}
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
          </div>
        ) : projects.length === 0 ? (
          <Card className="border border-slate-200">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FolderKanban className="w-12 h-12 text-slate-300 mb-4" />
              <p className="text-slate-500 mb-4">No projects found</p>
              <Link to="/clients">
                <Button data-testid="go-to-clients-btn">
                  Add Projects via Clients
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <Card className="border border-slate-200 shadow-sm" data-testid="projects-table-card">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/80">
                      <TableHead className="font-semibold text-xs uppercase tracking-wider">Project</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider">Client</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider">Status</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider">Priority</TableHead>
                      <TableHead className="font-semibold text-xs uppercase tracking-wider">Due Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((project) => (
                      <TableRow 
                        key={project.id}
                        className="hover:bg-slate-50 transition-colors"
                        data-testid={`project-row-${project.id}`}
                      >
                        <TableCell>
                          <Link 
                            to={`/clients/${project.client_id}`}
                            className="font-medium text-slate-900 hover:text-emerald-600 transition-colors"
                          >
                            {project.name}
                          </Link>
                          {project.description && (
                            <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 max-w-xs">
                              {project.description}
                            </p>
                          )}
                        </TableCell>
                        <TableCell>
                          <Link 
                            to={`/clients/${project.client_id}`}
                            className="text-sm text-slate-600 hover:text-emerald-600 transition-colors"
                          >
                            {project.client_name}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <Badge className={cn("text-xs whitespace-nowrap", getStatusClass(project.status))}>
                            {project.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={cn("text-xs", getPriorityClass(project.priority))}>
                            {project.priority}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {isOverdue(project.due_date) && project.status !== 'Completed' && project.status !== 'Issued' && (
                              <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                            )}
                            <span className={cn(
                              "text-sm whitespace-nowrap",
                              isOverdue(project.due_date) && project.status !== 'Completed' && project.status !== 'Issued'
                                ? "text-rose-600 font-medium"
                                : "text-slate-600"
                            )}>
                              {formatDate(project.due_date)}
                            </span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Status Summary */}
        {!loading && projects.length > 0 && (
          <Card className="border border-slate-200 shadow-sm" data-testid="status-summary-card">
            <CardContent className="p-6">
              <h3 className="font-semibold text-slate-900 mb-4">Projects by Status</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                {PROJECT_STATUSES.filter(s => groupedByStatus[s].length > 0).map((status) => (
                  <button
                    key={status}
                    onClick={() => setStatusFilter(status)}
                    className={cn(
                      "p-3 rounded-lg border text-left transition-all hover:shadow-md",
                      statusFilter === status 
                        ? "border-emerald-500 bg-emerald-50" 
                        : "border-slate-200 bg-slate-50 hover:border-slate-300"
                    )}
                    data-testid={`status-btn-${status.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    <Badge className={cn("text-xs mb-2", getStatusClass(status))}>
                      {groupedByStatus[status].length}
                    </Badge>
                    <p className="text-xs text-slate-600 line-clamp-2">{status}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
